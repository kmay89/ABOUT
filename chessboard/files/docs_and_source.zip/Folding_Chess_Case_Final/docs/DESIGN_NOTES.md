# Design notes: what the fit tests taught

## Lessons from printed test sets

| Tried | What happened | Final decision |
|---|---|---|
| Spring clips in each piece nest | Not needed: the closed lid already traps every piece. The clips added fiddle and wear. | **Removed.** Plain contoured nests with 0.35 mm clearance. |
| One-sided corner snap (0.15 mm overlap) | Too loose: 0.25 mm of lid play from the hinge and pegs was bigger than the snap. | **Replaced** with a twin-sided centre latch. Lid play now only shifts load between its two sides. |
| Magnets alone | A pleasant pull, but a weak hold against a bag knock | **Optional extra** on top of the latch |
| Teardrop-knuckle hinge, 1.75 mm filament pin | Worked first time, with good tolerances | **Kept unchanged** |
| Corner peg/socket alignment | Good registration | **Kept**. The pegs and knuckles are also the feet in play position. |

## Principles carried into the final version
1. **Grip from both sides.** Any snap whose hold depends on a single interference smaller than the assembly's
   play will feel random from print to print.
2. **Long, soft springs beat short, stiff ones.** A larger deflection makes the force tolerant of ±0.1 mm print error.
3. **Bend in the layer plane.** The latch springs flex sideways, so the stress runs along the extruded lines.
4. **Design to the extrusion width.** The springs are exactly 2 lines (0.8 mm) wide, so they print as clean
   perimeters with no gap fill.
5. **Every overhang ≤ 45°, bridges only where intended.** Nothing needs supports.
6. **Simulate the motion.** The hinge was swept 0–180° and the latch closing was checked against the full meshes.

## Finishing pass (final version)
- Latch end posts: rounded in plan (r 1.2 mm) with a stepped 0.4 mm top chamfer. No sharp corners at the finger.
- 0.4 mm edge breaks around the latch slot (tray) and tongue pocket (lid), matching the nest chamfers.
- Queen crown points widened to 1.6 mm bases so they print crisply with a 0.4 nozzle.
- Existing details:
  - 0.6 mm outer chamfer and a 0.4 mm chamfer at the hinge seam
  - rounded case corners
  - finger notch for opening
  - engraved coordinates and frame line

## Two colours, more style (final)
- **Two filaments for the whole kit:** Light + Black. The case body, light squares and border are one part, so the
  board needs a single colour swap per layer (first 4 layers only). Marble is the default light colour, so the board
  matches the marble pieces like a stone set. White works the same way.
- **Thick-and-thin frame:** a 0.5 mm outer rule follows the rounded corners, inside the existing 0.8 mm frame line.
  This is the classic engraved-frame look of tournament boards.
- **Compass stars:** an 8-point star sits in each board corner. The same star, in relief, is the tray's ornament,
  so the inside and outside share one motif.
- **ERRERLabs maker's panel:** a 9 × 39.5 mm panel recessed 0.6 mm into the lid's centre strip, with the wordmark
  in raised Crimson Text Bold, flush with the rim.
  - It reads upward from the hinge and is seen whenever the case is opened, like the maker's mark inside a
    jewellery box.
  - The face border is fully used by coordinates. Lettering there would have been too small to print legibly, so
    the mark lives inside.
  - **Printability:** strokes thickened 0.06 mm (hairlines ≥ 0.5 mm) and 0.45 mm extra letter-spacing, checked by
    morphological opening at 0.42 mm (one nozzle line). Only serif tips round over.
- **Single-colour kit:** the rules, stars and lettering become crisp 0.8 mm-deep engravings on the face.

## Verification of the final geometry
- All meshes closed and manifold. Minimum floor under the nests: 2.35 mm.
- **Hinge sweep 0–180°:** 0 collisions over 2.3 M sampled points.
- **Latch closing:**
  - contact is on the springs only
  - peak deflection 0.59 mm (designed 0.60)
  - 0.03 mm preload left at closed
  - no contact with the posts, slot or pocket
- **Corner pegs in sockets:** 0 interference in both editions.
- **Bambu projects:**
  - XML and references valid
  - every plate inside the bed and clear of the prime tower
  - pause layers land exactly on the pocket heights
