# Print guide

Each half is 218 × 113 mm and fits any 220 × 220 mm bed.
- **Half A = lid** (ranks 1–4).
- **Half B = tray** (ranks 5–8).

## Files (per edition, in `STL/<edition>/`)

| Folder | Contents | Use when |
|---|---|---|
| `1_fit_test` | `fit_test_A/B`: hinge, latch, corner peg + socket | Print first on any printer  |
| `2_board_two_colour` | `half_A_light` + `half_A_dark`, `half_B_…` | AMS / MMU / toolchanger (2 colours) |
| `3_board_single_colour` | `mono_half_A/B` + `mono_inlay_tiles` | Single-extruder printers |
| `4_pieces` | `pieces_marble`, `pieces_black` (16 each) | Everyone |

## Settings

| | Board halves | Pieces | Inlay tiles |
|---|---|---|---|
| Layer / first layer | 0.20 / **0.20** | 0.16 / **0.20** | 0.20 / 0.20 |
| Walls / infill | 3 / 15 % gyroid | Standard: **100 %**. Magnets + Weights: 3 walls / 15 % | 100 % |
| Bottom | 5 layers, Monotonic line | — | — |
| Supports | none | none | none |
| Plate | textured PEI (matte face) or smooth PEI (gloss) | any | smooth PEI |
| Seam | default | scarf, or aligned at the back | — |

**Two colours:** load both STLs of a half as **one object with multiple parts**. Assign light → Marble (or White) and
dark → Black. The dark part holds the dark squares, coordinates, both frame rules and the corner stars. All colour
changes happen in the first 4 layers, so there's one swap per layer and very little purge.
Turn on Flush into object infill.

**Small details:** the thin outer rule is 0.5 mm wide (one first-layer line) and the star points are ≥ 0.6 mm at the
base. Keep the default first-layer line width (0.5 mm) and a clean, well-levelled plate.

**ERRERLabs panel:** raised 0.6 mm (3 layers) in a recessed panel on the lid's centre strip. The letters are
thickened by 0.06 mm so every stroke is ≥ 0.5 mm, and spaced so the serifs never fuse. Leave ironing off; the
default top surface gives the lettering a clean satin finish.

**Single colour:** print `mono_half_A/B` in a light colour and the tiles in a dark colour. Press each tile in with a
drop of CA. The tiles print face-down, so they match the board's surface.

## Pauses (Magnets + Weights edition only; already in its 3MF)

| Part | Pause at | Insert |
|---|---|---|
| Each half / fit test | **7.80 mm** | 6×3 magnet, socket pocket, **dot DOWN** |
| Each half / fit test | **15.60 mm** | 6×3 magnet, peg pocket, **dot UP** |
| Pieces | first layer above **5.00 mm** (5.16 at 0.16 mm layers) | Fill cavities flush: tungsten putty, or shot + thin CA |

- Stack the 4 magnets and dot each top face before you start.
- Put a drop of CA in each pocket first, so the magnet can't jump to the nozzle.
- A skipped pause just leaves a sealed empty pocket.

## Troubleshooting
- **Pin won't go in:** twist a 2 mm drill bit through the knuckles by hand.
- **Peg won't seat:** you're over-extruding. Calibrate flow, or sand the peg lightly.
- **Latch too stiff or too loose:** set `LATCH_DELTA` in `source/case.py` (0.5 = softer, 0.6 = default, 0.7 = firmer).
  Then rebuild with `python3 make_3mf.py` (add `--no-hardware` for Standard).
- **Halves rock when open:** that's elephant's foot. Enable compensation (0.1–0.15 mm).
- **Pieces too loose or tight in the nests:** `C_NEST` in `source/case.py` (default 0.35 mm).
