# ERRERLabs Folding Travel Chess Case: printed hinge, snap latch, two colours, no supports

A chess set that folds into a 24 mm thick case holding all 32 pieces. Open it and it's a 25 mm-square board.
The playing surface is printed face-down in two colours, so it comes off the plate smooth and crisp.

**Highlights**
- **Just two filaments** for the whole set: marble (or white) and black.
- Thick-and-thin double rule, compass-star corners, and the ERRERLabs maker's mark in raised serif lettering inside the lid.
- Fits 220 × 220 mm beds. Each half prints on its own plate.
- Ready-to-print Bambu Studio projects for AMS, with colours, plates and pauses set up.
- Single-colour kit included: a pocketed board plus press-in inlay tiles.
- Printed teardrop-knuckle hinge with a 1.75 mm filament pin. Hard stop at flat.
- Engineered twin-spring snap latch: a firm click, holds about 640 g, and pulls the lid shut so it doesn't rattle.
- Contoured nests for every piece. Staunton-style pieces with a 44 mm king.
- Two editions:
  - **Standard:** nothing to buy, solid pieces.
  - **Magnets + Weights:** corner magnets and ballasted pieces, with print pauses already set.
- A fit-test print  checks the hinge, latch and corner registration before the long prints.

**Plates:**
1. fit test
2. lid
3. tray
4. marble pieces
5. black pieces

**You need:** about 22 cm of 1.75 mm filament for the hinge pin.
**Magnets + Weights edition only:** 4 × 6×3 mm magnets and about 110 g of tungsten putty.

Print settings, pause heights and assembly are in the included START_HERE and PRINT_GUIDE.
Cover images: `renders/1_board.png`, `2_open_storage.png`, `3_closed.png`, `4_corner_star.png`, `5_ERRERLabs_panel.png`.
