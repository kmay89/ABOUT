# Centre latch (final): design note

**Goal:** a snap that is secure and satisfying, survives thousands of cycles in printed PLA, and works on any
reasonably tuned printer.

## Why the earlier latches had to change
| Problem | Fix in the final latch |
|---|---|
| Short, stiff springs: 0.3 mm deflection, so a ±0.1 mm print error changed the force by ±33 % | Long, soft springs: 0.6 mm deflection, so ±0.1 mm gives ±17 % |
| Snap force depended on bar thickness, which drives the strain | Force from **parallel springs** (2 per side) and taller beams, with the strain kept low |
| Tiny lead-in, no draw-down | 27° lead-in, 45° draw-down shoulder, 0.08 mm preload |

## Architecture
- **Tongue (lid):** 2.4 mm neck, 5 mm long. The barb has a 27° entry ramp, a 0.2 mm flat crest, and a 45° shoulder.
  It prints upright with every overhang at 45° or less.
- **Springs (tray):** two **fixed-fixed bridge beams** per side, 0.8 mm thick (exactly 2 extrusion lines, no gap
  fill), 44 mm span, 4.6 mm tall. A centre pad ties each pair together so they act as one spring.
- **Layer direction:** the beams bend sideways, in the layer plane, so the stress runs along the filament.
  That's the strongest and most fatigue-resistant direction in an FDM part.
- **Support-free:** each beam's first layer is a 44 mm bridge between anchors, which the P2S prints cleanly.
  Root fillets (r 1.0 mm, 0.35 mm between beams) take the stress concentration out of the beam roots.
- **Twin-sided grip:** the tongue is squeezed from both sides. Lid play from the hinge and pegs (±0.25 mm) only
  shifts load between sides; the total grip stays the same. That's what defeated the earlier one-sided latches.
- **Self-limiting deflection:** the barb's own shape caps beam travel at 0.6 mm (+0.25 mm worst-case lid play),
  and there's 1.15 mm of free room behind each spring. They can't be over-bent by forcing the lid.
- **Draw-down:** when closed, the 45° shoulder rests on the beams with 0.08 mm of preload. That pulls the lid shut
  with no rattle. The preload strain is about 0.05 %, so creep is negligible.

## Numbers (beam model in `source/snapfit_model.py`)
| | Value |
|---|---|
| Working strain (incl. stretching, root stress factor 1.25) | **0.41 %** (~12 MPa); worst case ~0.58 % |
| Close force at the latch | **~330 g** (276–386 g over ±0.1 mm print error) |
| Hold force at the latch | **~640 g** (536–750 g) |
| Felt at the finger dish | ~0.68 × those values (lever ratio 74/109) |
| Pull-in after the crest | up to ~180 g, which pulls the lid shut |
| Stored energy released at the snap | ~1 mJ, enough for an audible click |

PLA endurance at 12 MPa is well into the hundreds of thousands of cycles. A chess case sees a few thousand.

## Verification
- **Closing simulation (0–180°, `verify_latch.py`):**
  - the tongue touches only the springs, and only in the last ~5°
  - peak spring deflection is 0.59 mm (designed 0.60)
  - at closed, only the designed preload is left
  - nothing ever touches the end posts, the slot floor or the lid pocket
- **Hinge simulation:** unchanged, no collisions.
- **Play position:** tongue (3.5 mm) and springs (3.4 mm) both stay below the 3.8 mm feet.

## Tuning
`LATCH_DELTA` in `source/case.py` sets the snap. Default 0.6 mm.

| Value | Hold | Close | Strain |
|---|---|---|---|
| 0.5 mm | ~535 g | ~275 g | 0.34 % |
| 0.6 mm (default) | ~640 g | ~330 g | 0.41 % |
| 0.7 mm | ~750 g | ~385 g | 0.48 % |

Don't go above 0.75 mm. Rebuild with `python3 make_3mf.py` (add `--no-hardware` for that version).
