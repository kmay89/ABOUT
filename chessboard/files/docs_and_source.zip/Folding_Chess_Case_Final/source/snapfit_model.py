"""Fixed-fixed in-plane beam pushed by a rigid straight tongue (contacts at the tongue ends -> two symmetric
point loads). Euler-Bernoulli FE + membrane (stretching) strain estimate. Units: mm, N, MPa."""
import numpy as np

E = 3200.0            # printed PLA, in-plane (along the lines)
MU = 0.3              # PLA on PLA
RHO = np.degrees(np.arctan(MU))

def beam_fe(L, h, t, a_load, n=400):
    """Return (k, mmax_per_P, shape) for symmetric point loads P at a_load from each end; fixed-fixed."""
    I = h * t ** 3 / 12.0
    x = np.linspace(0, L, n + 1); le = L / n
    K = np.zeros((2 * (n + 1), 2 * (n + 1)))
    ke = E * I / le ** 3 * np.array([[12, 6 * le, -12, 6 * le], [6 * le, 4 * le ** 2, -6 * le, 2 * le ** 2],
                                     [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le ** 2, -6 * le, 4 * le ** 2]])
    for e in range(n):
        d = [2 * e, 2 * e + 1, 2 * e + 2, 2 * e + 3]
        K[np.ix_(d, d)] += ke
    F = np.zeros(2 * (n + 1))
    i1, i2 = int(round(a_load / le)), int(round((L - a_load) / le))
    F[2 * i1] += 1.0; F[2 * i2] += 1.0
    free = np.arange(2, 2 * n)                 # clamp both ends (w, theta)
    u = np.zeros_like(F); u[free] = np.linalg.solve(K[np.ix_(free, free)], F[free])
    w = u[0::2]
    # moment from curvature
    curv = np.gradient(np.gradient(w, x), x)
    M = E * I * np.abs(curv)
    return 1.0 / w[i1], M.max(), w / w[i1], x

def evaluate(L, h, t, delta, Lt, kt=1.25):
    a = (L - Lt) / 2
    k, m_per_P, shape, x = beam_fe(L, h, t, a)
    P = k * delta                                # per contact point
    sig_b = (m_per_P * P) * (t / 2) / (h * t ** 3 / 12) * kt
    w = shape * delta
    eps_m = 0.5 * np.trapezoid(np.gradient(w, x) ** 2, x) / L      # membrane (stretching) strain
    eps = sig_b / E + eps_m
    lat = 2 * P                                   # lateral force on the tongue from one beam
    ins = 2 * lat * np.tan(np.radians(25 + RHO))  # two beams, 25 deg entry ramp
    ret = 2 * lat * np.tan(np.radians(45 + RHO))  # two beams, 45 deg shoulder
    return dict(L=L, h=h, t=t, d=delta, Lt=Lt, eps=eps * 100, sig=sig_b, ins_g=ins / 9.81 * 1000, ret_g=ret / 9.81 * 1000,
                dret=lambda dd: None)

if __name__ == "__main__":
    print("v8 as designed (centre load, L32 t1.0 h3.4 d0.30):")
    r = evaluate(32, 3.4, 1.0, 0.30, 0.01); print({k: round(v, 3) for k, v in r.items() if k != 'dret'})
    rows = []
    for L in (36, 40, 44, 48):
        for t in (0.8, 1.0):
            for d in (0.5, 0.6, 0.7, 0.8):
                for Lt in (0.01, L * 0.35, L * 0.5):
                    r = evaluate(L, 3.4, t, d, Lt)
                    rows.append(r)
    ok = [r for r in rows if r["eps"] <= 0.45]
    ok.sort(key=lambda r: -r["ret_g"])
    print("\nbest designs with total strain <= 0.45 % (incl. membrane, Kt 1.25 at the roots):")
    for r in ok[:10]:
        print(f"L={r['L']:.0f} t={r['t']} d={r['d']} Lt={r['Lt']:.1f}  strain {r['eps']:.2f}%  sigma {r['sig']:.1f} MPa  "
              f"close {r['ins_g']:.0f} g  hold {r['ret_g']:.0f} g")


def final(L=44, h=4.6, t=0.8, d=0.6, nbeam=2, entry=27, shoulder=45, pre=0.08):
    r = evaluate(L, h, t, d, 0.01)
    k_side = nbeam * (2 * evaluate(L, h, t, 1.0, 0.01)["ins_g"] / 2)   # placeholder (not used)
    a = (L - 0.01) / 2
    kb, _, _, _ = beam_fe(L, h, t, a)
    k_side = nbeam * 2 * kb            # N/mm lateral, one side (two coincident unit loads -> 2*kb)
    out = {"strain %": r["eps"], "sigma MPa": r["sig"]}
    for dd in (d - 0.1, d, d + 0.1):
        lat = k_side * dd
        out[f"close g (d={dd:.2f})"] = 2 * lat * np.tan(np.radians(entry + RHO)) / 9.81 * 1000
        out[f"hold g (d={dd:.2f})"] = 2 * lat * np.tan(np.radians(shoulder + RHO)) / 9.81 * 1000
    out["preload pull-down g"] = 2 * k_side * pre * np.tan(np.radians(shoulder - RHO)) / 9.81 * 1000
    out["stored energy mJ"] = 2 * 0.5 * k_side * d ** 2
    out["k_side N/mm"] = k_side
    return out

print("\nchosen: L44 h4.6 t0.8, 2 beams per side, delta 0.6, centre contact")
for k, v in final().items():
    print(f"  {k:24s} {v:8.2f}")
