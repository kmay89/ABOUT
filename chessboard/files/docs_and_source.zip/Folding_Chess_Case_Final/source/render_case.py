import numpy as np, time, sys
from render import render
from case import *
from pieces import build, BACK_RANK
from meshlib import merge, Mesh

t0 = time.time()
nests, _, _ = layout()
halves = {h: build_half(h, nests)[0] for h in "AB"}
LIGHT = "white" if "--light-white" in sys.argv else "marble"
mats = {"body": LIGHT, "white": LIGHT, "black": "black", "marble": LIGHT}
def half_items(h, M=None, T=(0, 0, 0)):
    out = []
    for name, shells in halves[h].items():
        m = merge(shells)
        if M is not None:
            m = m.apply(M)
        out.append((m.translate(*T), mats[name]))
    return out

piece_cache = {}
def piece(kind, n=64):
    if kind not in piece_cache:
        piece_cache[kind] = build(kind, n, weights=False)[0]
    return piece_cache[kind]

# ---- 1. hero: open flat, playing side up, set up for a game (play frame)
P2G = np.diag([1.0, -1.0, -1.0])      # G -> play: (x, y, z) -> (x, -y, -z) then shift
items = []
for h in "AB":
    items += half_items(h, P2G, (0, HD, H))
for f in range(8):
    for r, kind_row, mat in [(0, BACK_RANK, "marble"), (1, ["pawn"] * 8, "marble"),
                             (7, BACK_RANK, "black"), (6, ["pawn"] * 8, "black")]:
        kind = kind_row[f]
        m = piece(kind)
        if kind == "knight":
            m = m.rotate_z(90 if mat == "marble" else -90)
        items.append((m.translate(B_ + (f + 0.5) * S, B_ + (r + 0.5) * S, H), mat))
img = render(items, eye=(W / 2 - 150, -230, 260), target=(W / 2, W / 2 - 10, 0), size=(1400, 1000), fov=30)
img.save("v10_out/render_board.png"); print("board", time.time() - t0)

# ---- 2. open, trays up, pieces stored in half A (G frame)
items = half_items("A") + half_items("B")
for n in nests:
    is_marble = n["xc"] < W / 2
    m = piece(n["kind"])
    Rlay = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)   # piece axis (z) -> -y: stored in tray B
    m = m.apply(Rlay).translate(n["xc"], -n["y0"], H)
    items.append((m, "marble" if is_marble else "black"))
img = render(items, eye=(W / 2 + 60, -260, 300), target=(W / 2, 0, 0), size=(1400, 1000), fov=30)
img.save("v10_out/render_open.png"); print("open", time.time() - t0)

# ---- 3. closed case (A folded over B), seen from the front-right
t = np.radians(180)
Rx = np.array([[1, 0, 0], [0, np.cos(t), -np.sin(t)], [0, np.sin(t), np.cos(t)]])
items = half_items("B")
for name, shells in halves["A"].items():
    m = merge(shells).translate(0, 0, -H).apply(Rx).translate(0, 0, H)
    items.append((m, mats[name]))
img = render(items, eye=(W + 120, -HD - 230, 150), target=(W / 2, -HD / 2, 8), size=(1400, 900), fov=30)
img.save("v10_out/render_closed.png"); print("closed", time.time() - t0)
