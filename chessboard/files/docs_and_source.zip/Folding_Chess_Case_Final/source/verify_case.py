"""Simulate folding lid A over tray B (0..180 deg) in the hinge zone (latch: see verify_latch.py)."""
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from matplotlib.path import Path
from case import *

nests, _, _ = layout()
L_ = latch()
xsA, ysA = grid([L_["pocket"]])
xsB, ysB = grid([L_["slot"]])
hA = body_heights(0, True, xsA, ysA, nests, latch_geom=L_, role="lid")
hB = body_heights(1, False, xsB, ysB, nests, latch_geom=L_, role="tray")
iA = RegularGridInterpolator((ysA, xsA), hA, bounds_error=False, fill_value=-1)
iB = RegularGridInterpolator((ysB, xsB), hB, bounds_error=False, fill_value=-1)
outer, hole = knuckle_poly()
PO, PH = Path(outer), Path(hole)

def in_knuckle(x, y, z, parity):
    inseg = np.zeros(len(x), bool)
    for k in range(N_K):
        if k % 2 == parity:
            a, b = seg_range(k)
            inseg |= (x >= a) & (x <= b)
    yz = np.c_[y, z]
    return inseg & PO.contains_points(yz, radius=-1e-6) & ~PH.contains_points(yz)

def in_half(x, y, z, h_interp, parity, tol, tray=False):
    hb = np.full(len(x), -1.0)
    m = (y >= 0) & (y <= HD) & (x >= 0) & (x <= W)
    hb[m] = h_interp(np.c_[y[m], x[m]])
    body = m & (z > tol) & (z < hb - tol) & (y > tol)
    out = body | in_knuckle(x, y, z, parity)
    return out

def sweep(X, Y, Z, angles, label):
    inA = in_half(X, Y, Z, iA, 0, 0.0)
    X, Y, Z = X[inA], Y[inA], Z[inA]
    worst = 0
    for deg in angles:
        t = np.radians(deg)
        y2 = Y * np.cos(t) - (Z - H) * np.sin(t)
        z2 = Y * np.sin(t) + (Z - H) * np.cos(t) + H
        n = in_half(X, -y2, z2, iB, 1, 0.02, tray=True).sum()
        worst = max(worst, n)
        if n:
            print(f"  {label} {deg} deg: {n} collisions")
    print(f"{label}: {len(X)} lid points, max collisions {worst}")

# 1) hinge zone, dense near knuckle boundaries
xv = []
for k in range(N_K + 1):
    xv += list(k * L_K + np.arange(-1.0, 1.01, 0.125))
xv += list((np.arange(N_K) + 0.5) * L_K)
xv = np.clip(np.unique(np.round(xv, 4)), 0, W)
X, Y, Z = [a.ravel() for a in np.meshgrid(xv, np.arange(-4.5, 10.0, 0.1), np.arange(0.0, H + 4.5, 0.1), indexing="ij")]
sweep(X, Y, Z, range(0, 181, 3), "hinge")
