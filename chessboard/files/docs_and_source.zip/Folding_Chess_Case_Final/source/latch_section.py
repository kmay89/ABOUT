import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from case import *
L = latch()
xc = L["xc"]
fig, ax = plt.subplots(figsize=(8, 5.4), dpi=140)
# tray (B) section through the latch: slot + beams
sw = L["sw"]
sf = L["slot_floor"]
ax.fill([xc - 9, xc - sw, xc - sw, xc + sw, xc + sw, xc + 9, xc + 9, xc - 9],
        [H, H, sf, sf, H, H, D, D], color="#eee", ec="#333", lw=.7, label="tray")
for s_ in (-1, 1):
    for j in range(BEAM_N):
        u0 = BEAM_IN + j * (BEAM_T + BEAM_SEP)
        xa = xc + s_ * u0; xb = xc + s_ * (u0 + BEAM_T)
        ax.add_patch(plt.Rectangle((min(xa, xb), BEAM_BOT), BEAM_T, BEAM_TOP - BEAM_BOT, color="#5a8",
                                   label="twin bridge beams (in-plane springs)" if (s_ < 0 and j == 0) else None))
# lid (A) closed: pocket + tongue (mirror z about the parting line)
pk = sw + 0.4
lz = lambda z: 2 * H - z
ax.fill([xc - 9, xc - pk, xc - pk, xc + pk, xc + pk, xc + 9, xc + 9, xc - 9],
        [H, H, lz(POCKET_FLOOR), lz(POCKET_FLOOR), H, H, 2 * H - D, 2 * H - D], color="#ddd", ec="#333", lw=.7, alpha=.9, label="lid (closed)")
T = L["tongue"]
ax.fill(T[:, 0], lz(T[:, 1]), color="#c55", label="tongue + barb")
ax.axhline(H, color="#c33", lw=.5, ls="--")
ax.set_xlim(xc - 9, xc + 9); ax.set_ylim(D, 2 * H - D); ax.set_aspect("equal"); ax.legend(fontsize=7, loc="lower left")
ax.set_title(f"v9 latch, closed: barb spreads each twin-beam spring {LATCH_DELTA:.1f} mm to pass, then the 45 deg\n"
             f"shoulder rests on the beams with {LATCH_PRE:.2f} mm preload (draw-down, no rattle). Span {LATCH_L:.0f} mm, in-plane bending", fontsize=8.5)
fig.tight_layout(); fig.savefig("v9_out/preview_latch.png", facecolor="white")
