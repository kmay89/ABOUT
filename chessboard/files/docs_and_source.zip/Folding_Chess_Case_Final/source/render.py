"""Small numpy z-buffer renderer with deferred shading (for previews)."""
import numpy as np
from PIL import Image

MATS = {
    "marble": dict(base=(0.86, 0.85, 0.82), spec=0.25, shin=30, speck=True),
    "black": dict(base=(0.07, 0.07, 0.08), spec=0.45, shin=40, speck=False),
    "white": dict(base=(0.93, 0.93, 0.91), spec=0.2, shin=25, speck=False),
    "grey": dict(base=(0.55, 0.55, 0.56), spec=0.2, shin=20, speck=False),
    "felt": dict(base=(0.20, 0.22, 0.28), spec=0.02, shin=5, speck=False),
}


def vertex_normals(V, F):
    fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    vn = np.zeros_like(V)
    for i in range(3):
        np.add.at(vn, F[:, i], fn)
    return vn / (np.linalg.norm(vn, axis=1, keepdims=True) + 1e-12), fn


def look_at(eye, target, up=(0, 0, 1)):
    eye, target, up = map(lambda a: np.asarray(a, float), (eye, target, up))
    f = target - eye; f /= np.linalg.norm(f)
    r = np.cross(f, up); r /= np.linalg.norm(r)
    u = np.cross(r, f)
    return eye, np.stack([r, u, f])


def render(items, eye, target, size=(1200, 800), fov=30, ssaa=2, bg=(1, 1, 1), flat_angle=35):
    """items: list of (Mesh, material_name). Returns PIL image."""
    Wp, Hp = size[0] * ssaa, size[1] * ssaa
    eye, R = look_at(eye, target)
    f = 0.5 * Hp / np.tan(np.radians(fov) / 2)
    zbuf = np.full((Hp, Wp), np.inf)
    nbuf = np.zeros((Hp, Wp, 3)); pbuf = np.zeros((Hp, Wp, 3)); mbuf = np.full((Hp, Wp), -1, int)
    names = list(MATS)
    for m, mat in items:
        V, F = m.V, m.F
        # split vertices on sharp edges: use face normals where they differ a lot from vertex normals
        vn, fn = vertex_normals(V, F)
        fnn = fn / (np.linalg.norm(fn, axis=1, keepdims=True) + 1e-12)
        C = (V - eye) @ R.T
        zc = C[:, 2]
        sx = Wp / 2 + f * C[:, 0] / zc
        sy = Hp / 2 - f * C[:, 1] / zc
        tri_s = np.stack([sx[F], sy[F]], -1)          # (n,3,2)
        area = ((tri_s[:, 1, 0] - tri_s[:, 0, 0]) * (tri_s[:, 2, 1] - tri_s[:, 0, 1])
                - (tri_s[:, 2, 0] - tri_s[:, 0, 0]) * (tri_s[:, 1, 1] - tri_s[:, 0, 1]))
        keep = (area < -1e-9) & (zc[F].min(1) > 0)   # front-facing (screen y flipped)
        cosang = np.cos(np.radians(flat_angle))
        mid = names.index(mat)
        for t in np.nonzero(keep)[0]:
            (x0, y0), (x1, y1), (x2, y2) = tri_s[t]
            xmin, xmax = int(max(np.floor(min(x0, x1, x2)), 0)), int(min(np.ceil(max(x0, x1, x2)), Wp - 1))
            ymin, ymax = int(max(np.floor(min(y0, y1, y2)), 0)), int(min(np.ceil(max(y0, y1, y2)), Hp - 1))
            if xmin > xmax or ymin > ymax:
                continue
            px, py = np.meshgrid(np.arange(xmin, xmax + 1) + 0.5, np.arange(ymin, ymax + 1) + 0.5)
            a = area[t]
            w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) / a
            w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) / a
            w2 = 1 - w0 - w1
            ins = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
            if not ins.any():
                continue
            i0, i1, i2 = F[t]
            # perspective-correct depth
            iz = w0 / zc[i0] + w1 / zc[i1] + w2 / zc[i2]
            z = 1 / iz
            sub = zbuf[ymin:ymax + 1, xmin:xmax + 1]
            upd = ins & (z < sub)
            if not upd.any():
                continue
            sub[upd] = z[upd]
            b0, b1, b2 = (w0 / zc[i0] * z)[upd], (w1 / zc[i1] * z)[upd], (w2 / zc[i2] * z)[upd]
            fnt = fnn[t]
            ns = []
            for i in (i0, i1, i2):
                ns.append(vn[i] if vn[i] @ fnt > cosang else fnt)
            n = b0[:, None] * ns[0] + b1[:, None] * ns[1] + b2[:, None] * ns[2]
            p = b0[:, None] * V[i0] + b1[:, None] * V[i1] + b2[:, None] * V[i2]
            nb = nbuf[ymin:ymax + 1, xmin:xmax + 1]; nb[upd] = n
            pb = pbuf[ymin:ymax + 1, xmin:xmax + 1]; pb[upd] = p
            mb = mbuf[ymin:ymax + 1, xmin:xmax + 1]; mb[upd] = mid
    # deferred shading
    img = np.ones((Hp, Wp, 3)) * np.array(bg)
    hit = mbuf >= 0
    n = nbuf[hit]; n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
    p = pbuf[hit]
    vdir = eye - p; vdir /= np.linalg.norm(vdir, axis=1, keepdims=True)
    n = np.where((n * vdir).sum(1, keepdims=True) < 0, -n, n)
    lights = [(np.array([-0.5, -0.6, 0.8]), 0.85), (np.array([0.7, -0.3, 0.4]), 0.30), (np.array([0.2, 0.9, 0.5]), 0.35)]
    col = np.zeros((len(p), 3))
    mids = mbuf[hit]
    for k, name in enumerate(names):
        sel = mids == k
        if not sel.any():
            continue
        M = MATS[name]
        base = np.tile(np.array(M["base"]), (sel.sum(), 1))
        if M["speck"]:
            q = np.floor(p[sel] * 5.0).astype(np.int64)
            h = (q[:, 0] * 73856093) ^ (q[:, 1] * 19349663) ^ (q[:, 2] * 83492791)
            r = (h % 1000) / 1000.0
            base[r > 0.988] *= 0.3
            q2 = np.floor(p[sel] * 0.9).astype(np.int64)
            h2 = ((q2[:, 0] * 2654435761) ^ (q2[:, 1] * 40503) ^ (q2[:, 2] * 97)) % 1000 / 1000.0
            base *= (0.95 + 0.07 * h2)[:, None]
        c = base * 0.28
        for L, I in lights:
            L = L / np.linalg.norm(L)
            d = np.clip(n[sel] @ L, 0, 1)
            hv = L + vdir[sel]; hv /= np.linalg.norm(hv, axis=1, keepdims=True)
            s = np.clip((n[sel] * hv).sum(1), 0, 1) ** M["shin"]
            c += I * (base * d[:, None] + M["spec"] * s[:, None])
        col[sel] = c
    img[hit] = np.clip(col, 0, 1) ** (1 / 1.1)
    # soft contact shadow / ambient occlusion-ish edge darkening via depth discontinuity
    im = Image.fromarray((img * 255).astype(np.uint8))
    return im.resize(size, Image.LANCZOS)
