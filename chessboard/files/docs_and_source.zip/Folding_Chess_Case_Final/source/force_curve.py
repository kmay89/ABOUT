"""Force-travel curve of the v9 latch (vertical lid travel at the latch vs force), from the barb profile
and the beam stiffness of snapfit_model.py. Positive = force you push with, negative = latch pulls the lid in."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import case
from snapfit_model import beam_fe, RHO
L = case.latch()
kb, _, _, _ = beam_fe(case.LATCH_L, case.BEAM_BOT * 0 + (case.BEAM_TOP - case.BEAM_BOT), case.BEAM_T, case.LATCH_L / 2 - 0.005)
k_side = case.BEAM_N * 2 * kb
prof = [(u, z) for u, z in [tuple(p) for p in L["tongue"]] if u >= L["xc"]]   # right half, lid frame
U = np.array([p[0] - L["xc"] for p in prof]); Zl = np.array([p[1] for p in prof]); ZB = 2 * case.H - Zl
order = np.argsort(ZB); U, ZB = U[order], ZB[order]
s = np.linspace(-0.4, 4.0, 900)                     # lid height above closed, at the latch
zb = case.BEAM_BOT
def lateral(si):                                     # beam corner at zb meets the tongue lowered by -si
    w = np.interp(zb - si, ZB, U)                    # tongue half-width at the beam's bottom corner
    return max(0.0, w - case.BEAM_IN)
d = np.array([lateral(si) for si in s])
slope = np.gradient(np.array([np.interp(zb - si, ZB, U) for si in s]), s)   # dw/ds: + entry ramp side, - shoulder side
ang = np.degrees(np.arctan(np.abs(slope)))
F_close = np.where(slope < 0, 1, -1) * 2 * k_side * d * np.tan(np.radians(np.clip(ang + np.where(slope < 0, RHO, -RHO), -89, 89)))
F_open = -np.where(slope > 0, 1, -1) * 2 * k_side * d * np.tan(np.radians(np.clip(ang + np.where(slope > 0, RHO, -RHO), -89, 89)))
g = 1000 / 9.81
fig, ax = plt.subplots(figsize=(8, 4.2), dpi=140)
ax.plot(s, F_close * g, color="#2a7", label="closing (push down)")
ax.plot(s, -F_open * g, color="#c44", label="opening (pull up)")
ax.axhline(0, color="#999", lw=.6); ax.axvline(0, color="#999", lw=.6, ls=":")
ax.set_xlabel("lid height above fully closed, at the latch (mm)"); ax.set_ylabel("force at the latch (g)")
ax.set_xlim(-0.1, 3.0); ax.invert_xaxis(); ax.legend(fontsize=8)
ax.set_title(f"Latch force-travel: peak close {F_close.max() * g:.0f} g, peak hold {(-F_open).max() * g:.0f} g\n"
             "(latch sits 74 mm from the hinge; at the finger dish the felt forces are ~0.68x)", fontsize=9)
fig.tight_layout(); fig.savefig("v9_out/latch_force_curve.png", facecolor="white")
print("peak close g", round(F_close.max() * g), " peak hold g", round((-F_open).max() * g), " k_side", round(k_side, 2))
