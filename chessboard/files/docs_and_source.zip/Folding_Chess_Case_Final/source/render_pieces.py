import numpy as np, time
from render import render
from pieces import build
t0=time.time()
order = ["pawn", "rook", "knight", "bishop", "queen", "king"]
items = []
for row, mat in enumerate(["marble", "black"]):
    for i, k in enumerate(order):
        m, sh = build(k, 128, weights=False)
        rot = {"knight": 200 if row == 0 else 160}.get(k, 0)
        m = m.rotate_z(rot).translate(i * 24 - 60, row * 24, 0)
        items.append((m, mat))
img = render(items, eye=(-20, -150, 70), target=(0, 10, 16), size=(1400, 760), fov=26)
img.save("case_out/render_pieces.png")
m, _ = build("knight", 128, weights=False)
img = render([(m.rotate_z(205), "marble"), (m.rotate_z(-25).translate(22, 6, 0), "black")],
             eye=(-15, -80, 40), target=(10, 0, 15), size=(1000, 760), fov=28)
img.save("case_out/render_knight.png")
print(time.time()-t0)
