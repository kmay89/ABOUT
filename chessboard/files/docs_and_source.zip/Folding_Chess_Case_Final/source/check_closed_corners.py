"""Closed-state check of the corner boss (lid A) inside the socket (tray B), both variants."""
import sys, numpy as np
import case
from meshlib import merge

def inside(mesh, P):
    """Ray-cast (+z) parity test; vectorised over points, loop over triangles in chunks."""
    T = mesh.V[mesh.F]
    cnt = np.zeros(len(P), int)
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    for t in T:
        a, b, c = t
        d = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
        if abs(d) < 1e-12:
            continue
        l1 = ((b[1] - c[1]) * (x - c[0]) + (c[0] - b[0]) * (y - c[1])) / d
        l2 = ((c[1] - a[1]) * (x - c[0]) + (a[0] - c[0]) * (y - c[1])) / d
        l3 = 1 - l1 - l2
        m = (l1 >= 0) & (l2 >= 0) & (l3 >= 0)
        zt = l1 * a[2] + l2 * b[2] + l3 * c[2]
        cnt += (m & (zt > z)).astype(int)
    return cnt % 2 == 1

for magnets in (True, False):
    case.MAGNETS = magnets
    nb = 2 if magnets else 1
    A = case.corner_parts(True)            # lid: boss left, socket right
    Bs = [s.apply(case.MIRROR_Y) for s in case.corner_parts(False)]   # tray: boss right, socket left
    boss = A[0]
    bx, by = case.CORNER[0]
    g = np.mgrid[bx - 5.213:bx + 5.2:0.1, by - 5.217:by + 5.2:0.1, case.H + 0.053:case.BOSS_TOP:0.1].reshape(3, -1).T
    g = g[inside(boss, g)]
    if magnets:                                           # remove the cavity void
        g = g[~inside(A[1], g)]
    closed = np.c_[g[:, 0], -g[:, 1], 2 * case.H - g[:, 2]]
    socket_shells = Bs[nb:]
    hit = np.zeros(len(closed), bool)
    for s in socket_shells:
        hit |= inside(s, closed)
    # minimum gap from boss surface to socket material along the radial direction at the nub
    print(f"{'magnets' if magnets else 'snap latch'}: boss sample points {len(g)}, "
          f"interfering with socket {hit.sum()} ({hit.sum() * 1e-3:.3f} mm^3)")

# locate snap-latch interference
case.MAGNETS = False
sx, sy = case.CORNER[0][0], -case.CORNER[0][1]
pts = closed[hit]
r = np.hypot(pts[:, 0] - sx, pts[:, 1] - sy)
print("interfering points: r", r.min().round(2), "-", r.max().round(2),
      " depth below rim", (case.H - pts[:, 2]).min().round(2), "-", (case.H - pts[:, 2]).max().round(2),
      " dx", (pts[:, 0] - sx).min().round(2), (pts[:, 0] - sx).max().round(2), " dy", (pts[:, 1] - sy).min().round(2), (pts[:, 1] - sy).max().round(2))
