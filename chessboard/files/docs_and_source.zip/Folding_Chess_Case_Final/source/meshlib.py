"""Tiny dependency-free (numpy only) solid-modeling helpers for printable meshes."""
import struct
import numpy as np


class Mesh:
    def __init__(self, V, F):
        self.V = np.asarray(V, dtype=float).reshape(-1, 3)
        self.F = np.asarray(F, dtype=np.int64).reshape(-1, 3)

    def copy(self):
        return Mesh(self.V.copy(), self.F.copy())

    def translate(self, dx=0, dy=0, dz=0):
        m = self.copy()
        m.V += np.array([dx, dy, dz])
        return m

    def rotate_z(self, deg):
        a = np.radians(deg)
        R = np.array([[np.cos(a), -np.sin(a), 0], [np.sin(a), np.cos(a), 0], [0, 0, 1]])
        m = self.copy()
        m.V = m.V @ R.T
        return m

    def apply(self, M):
        m = self.copy()
        m.V = m.V @ np.asarray(M).T
        if np.linalg.det(M) < 0:
            m.F = m.F[:, ::-1]
        return m

    def volume(self):
        a, b, c = (self.V[self.F[:, i]] for i in range(3))
        return np.einsum("ij,ij->i", a, np.cross(b, c)).sum() / 6.0

    def oriented(self):
        m = self.copy()
        if m.volume() < 0:
            m.F = m.F[:, ::-1]
        return m

    def bounds(self):
        return self.V.min(0), self.V.max(0)


def merge(meshes):
    V, F, off = [], [], 0
    for m in meshes:
        V.append(m.V)
        F.append(m.F + off)
        off += len(m.V)
    return Mesh(np.vstack(V), np.vstack(F))


def check_closed(m):
    """Every directed edge must appear exactly once and its reverse exactly once."""
    F = m.F
    e = np.vstack([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    n = len(m.V) + 1
    key = e[:, 0] * n + e[:, 1]
    rkey = e[:, 1] * n + e[:, 0]
    uniq, cnt = np.unique(key, return_counts=True)
    if (cnt > 1).any():
        return False, f"{(cnt > 1).sum()} duplicated directed edges"
    missing = ~np.isin(rkey, uniq)
    if missing.any():
        return False, f"{missing.sum()} open edges"
    # degenerate faces
    a, b, c = (m.V[F[:, i]] for i in range(3))
    area = np.linalg.norm(np.cross(b - a, c - a), axis=1) / 2
    if (area < 1e-10).any():
        return False, f"{(area < 1e-10).sum()} zero-area faces"
    return True, "ok"


def write_stl(path, m, name="mesh"):
    tri = m.V[m.F]
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    ln = np.linalg.norm(n, axis=1, keepdims=True)
    ln[ln == 0] = 1
    n = n / ln
    data = np.zeros(len(tri), dtype=[("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    data["n"] = n
    data["v"] = tri
    with open(path, "wb") as f:
        f.write(name.encode()[:80].ljust(80, b"\0"))
        f.write(struct.pack("<I", len(tri)))
        f.write(data.tobytes())


# ---------------------------------------------------------------- primitives

def box(x0, y0, z0, x1, y1, z1):
    V = np.array([[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0],
                  [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]])
    F = [[0, 2, 1], [0, 3, 2], [4, 5, 6], [4, 6, 7], [0, 1, 5], [0, 5, 4],
         [1, 2, 6], [1, 6, 5], [2, 3, 7], [2, 7, 6], [3, 0, 4], [3, 4, 7]]
    return Mesh(V, F).oriented()


def lathe(profile, n=96):
    """profile: list of (r, z) from (0, z_bottom) ... to (0, z_top); interior r > 0."""
    P = np.asarray(profile, float)
    assert P[0, 0] == 0 and P[-1, 0] == 0 and (P[1:-1, 0] > 0).all(), "bad profile"
    inner = P[1:-1]
    k = len(inner)
    t = np.linspace(0, 2 * np.pi, n, endpoint=False)
    V = [[0, 0, P[0, 1]]]
    for r, z in inner:
        V += [[r * np.cos(a), r * np.sin(a), z] for a in t]
    V.append([0, 0, P[-1, 1]])
    V = np.array(V)
    top = len(V) - 1
    F = []
    ring = lambda i, j: 1 + i * n + (j % n)
    for j in range(n):
        F.append([0, ring(0, j + 1), ring(0, j)])
        F.append([top, ring(k - 1, j), ring(k - 1, j + 1)])
        for i in range(k - 1):
            a, b = ring(i, j), ring(i, j + 1)
            c, d = ring(i + 1, j + 1), ring(i + 1, j)
            F += [[a, b, c], [a, c, d]]
    return Mesh(V, F).oriented()


def check_overhang(profile, max_deg=50.0, label=""):
    """Return segments of a lathe profile whose outer surface overhangs more than max_deg from vertical."""
    bad = []
    P = np.asarray(profile, float)
    for (r0, z0), (r1, z1) in zip(P[:-1], P[1:]):
        if z1 > z0 + 1e-9 and r1 > r0 + 1e-9:  # going up and outward -> overhang
            ang = np.degrees(np.arctan2(r1 - r0, z1 - z0))
            if ang > max_deg:
                bad.append(((r0, z0), (r1, z1), round(ang, 1)))
        elif abs(z1 - z0) < 1e-9 and r1 > r0 + 1e-9 and z0 > 0.01:
            bad.append(((r0, z0), (r1, z1), 90.0))
    return bad


def arc(cx, cz, R, a0, a1, steps):
    """Points on circle in (r,z) plane, angles in degrees measured from +r axis."""
    a = np.radians(np.linspace(a0, a1, steps))
    return [(cx + R * np.cos(t), cz + R * np.sin(t)) for t in a]


# ---------------------------------------------------------------- 2D polygons

def signed_area(p):
    p = np.asarray(p)
    x, y = p[:, 0], p[:, 1]
    return 0.5 * (x * np.roll(y, -1) - np.roll(x, -1) * y).sum()


def clean_ring(p, tol=1e-4):
    p = [tuple(q) for q in np.asarray(p, float)]
    out = []
    for q in p:
        if not out or np.hypot(q[0] - out[-1][0], q[1] - out[-1][1]) > tol:
            out.append(q)
    while len(out) > 1 and np.hypot(out[0][0] - out[-1][0], out[0][1] - out[-1][1]) <= tol:
        out.pop()
    # drop collinear points
    changed = True
    while changed and len(out) > 3:
        changed = False
        for i in range(len(out)):
            a, b, c = np.array(out[i - 1]), np.array(out[i]), np.array(out[(i + 1) % len(out)])
            cr = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
            if abs(cr) < 1e-7:
                out.pop(i)
                changed = True
                break
    return np.array(out)


def _cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _bridge_holes(P, outer_idx, holes_idx):
    poly = list(outer_idx)
    holes = sorted(holes_idx, key=lambda h: -P[h, 0].max())
    for h in holes:
        hm = int(np.argmax(P[h, 0] + 1e-9 * P[h, 1]))
        M = P[h[hm]]
        best = None
        L = len(poly)
        for i in range(L):
            a, b = P[poly[i]], P[poly[(i + 1) % L]]
            if (a[1] - M[1]) * (b[1] - M[1]) > 0:
                continue
            if a[1] == b[1]:
                continue
            t = (M[1] - a[1]) / (b[1] - a[1])
            x = a[0] + t * (b[0] - a[0])
            if x < M[0] - 1e-9:
                continue
            if best is None or x < best[0]:
                cand = i if a[0] > b[0] else (i + 1) % L
                best = (x, cand)
        x, ci = best
        Pp = P[poly[ci]]
        I = np.array([x, M[1]])
        # reflex vertices inside triangle M, I, P -> pick the one with smallest angle
        tri = [M, I, Pp] if _cross(M, I, Pp) > 0 else [M, Pp, I]
        bestang = None
        for i in range(L):
            q = P[poly[i]]
            if i == ci:
                continue
            prev, nxt = P[poly[i - 1]], P[poly[(i + 1) % L]]
            if _cross(prev, q, nxt) > 0:  # convex, skip
                continue
            if q[0] < M[0]:
                continue
            if (_cross(tri[0], tri[1], q) >= 0 and _cross(tri[1], tri[2], q) >= 0
                    and _cross(tri[2], tri[0], q) >= 0):
                ang = abs(q[1] - M[1]) / max(q[0] - M[0], 1e-12)
                if bestang is None or ang < bestang:
                    bestang, ci = ang, i
        hole_seq = [h[(hm + k) % len(h)] for k in range(len(h))] + [h[hm]]
        poly = poly[:ci + 1] + hole_seq + poly[ci:]
    return poly


def triangulate(P, outer_idx, holes_idx=()):
    """Ear clipping with hole bridging. P: (N,2) points. outer CCW, holes CW. Returns list of index triples."""
    poly = _bridge_holes(P, outer_idx, holes_idx) if holes_idx else list(outer_idx)
    tris = []
    idx = poly[:]
    guard = 0
    while len(idx) > 3:
        n = len(idx)
        found = False
        Q = P[idx]
        for i in range(n):
            ia, ib, ic = idx[i - 1], idx[i], idx[(i + 1) % n]
            a, b, c = P[ia], P[ib], P[ic]
            if _cross(a, b, c) <= 1e-12:
                continue
            # points inside triangle (excluding coincident with a,b,c)
            d1 = (b[0] - a[0]) * (Q[:, 1] - a[1]) - (b[1] - a[1]) * (Q[:, 0] - a[0])
            d2 = (c[0] - b[0]) * (Q[:, 1] - b[1]) - (c[1] - b[1]) * (Q[:, 0] - b[0])
            d3 = (a[0] - c[0]) * (Q[:, 1] - c[1]) - (a[1] - c[1]) * (Q[:, 0] - c[0])
            inside = (d1 >= -1e-12) & (d2 >= -1e-12) & (d3 >= -1e-12)
            coinc = (np.all(np.isclose(Q, a), 1) | np.all(np.isclose(Q, b), 1)
                     | np.all(np.isclose(Q, c), 1))
            if (inside & ~coinc).any():
                continue
            tris.append((ia, ib, ic))
            idx.pop(i)
            found = True
            break
        if not found:
            # degenerate fallback: clip a zero-area/collinear vertex
            guard += 1
            if guard > 5:
                raise RuntimeError("triangulation failed")
            for i in range(n):
                a, b, c = P[idx[i - 1]], P[idx[i]], P[idx[(i + 1) % n]]
                if abs(_cross(a, b, c)) <= 1e-9:
                    idx.pop(i)
                    break
    if len(idx) == 3 and _cross(*P[idx]) > 1e-12:
        tris.append(tuple(idx))
    return tris


def extrude(outer, holes=(), z0=0.0, z1=1.0):
    outer = clean_ring(outer)
    holes = [clean_ring(h) for h in holes]
    if signed_area(outer) < 0:
        outer = outer[::-1]
    holes = [h if signed_area(h) < 0 else h[::-1] for h in holes]
    rings = [outer] + holes
    P = np.vstack(rings)
    offs = np.cumsum([0] + [len(r) for r in rings])
    ring_idx = [list(range(offs[i], offs[i + 1])) for i in range(len(rings))]
    tris = triangulate(P, ring_idx[0], ring_idx[1:])
    N = len(P)
    V = np.vstack([np.c_[P, np.full(N, z0)], np.c_[P, np.full(N, z1)]])
    F = []
    for a, b, c in tris:
        F.append([a, c, b])
        F.append([a + N, b + N, c + N])
    for r in ring_idx:
        for k in range(len(r)):
            i, j = r[k], r[(k + 1) % len(r)]
            F += [[i, j, j + N], [i, j + N, i + N]]
    return Mesh(V, F).oriented()


def loft_xz(polys, ys):
    """Loft same-count polygons in the XZ plane placed at given y values."""
    k = len(polys[0])
    V = []
    for p, y in zip(polys, ys):
        V += [[x, y, z] for x, z in p]
    V = np.array(V)
    F = []
    s = len(polys)
    for si in range(s - 1):
        for j in range(k):
            a, b = si * k + j, si * k + (j + 1) % k
            c, d = b + k, a + k
            F += [[a, c, b], [a, d, c]]
    P0 = np.asarray(polys[0])
    tris = triangulate(P0, list(range(k)))
    last = (s - 1) * k
    for a, b, c in tris:
        F.append([a, b, c])
        F.append([a + last, c + last, b + last])
    return Mesh(V, F).oriented()
