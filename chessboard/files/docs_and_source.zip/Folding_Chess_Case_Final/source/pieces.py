"""Staunton-style pieces sized for 25 mm squares, designed to print upright with no supports
(every lathe overhang <= 45-50 deg, bottom edge chamfered against elephant's foot)."""
import numpy as np
from meshlib import lathe, extrude, loft_xz, merge, check_overhang, arc, Mesh, signed_area

K = 1.0  # scale factor (pieces were designed for 25 mm squares)


def base(R):
    return [(0, 0), (R - 0.5, 0), (R, 0.5), (R, 1.7), (R - 0.9, 2.6), (R - 1.35, 3.0),
            (R - 1.05, 3.35), (R - 1.05, 3.9)]


def ball(neck_r, neck_z, R, steps=22):
    """Sphere sitting on a neck of radius neck_r at height neck_z; returns pts incl. top pole."""
    dz = np.sqrt(R * R - neck_r * neck_r)
    c = neck_z + dz
    a0 = np.degrees(np.arctan2(-dz, neck_r))
    pts = arc(0, c, R, a0, 90, steps)
    pts[-1] = (0.0, c + R)
    return pts[1:]  # first point == neck point


def profiles():
    P = {}
    P["pawn"] = base(7.25) + [(5.0, 5.1), (3.6, 6.0), (3.0, 7.5), (2.6, 10.0), (2.45, 12.2),
                              (4.1, 13.85), (4.1, 14.4), (2.65, 15.6), (2.65, 15.8)] + ball(2.65, 15.8, 3.6)
    P["rook"] = base(8.5) + [(6.2, 5.15), (5.2, 6.0), (4.9, 7.5), (4.9, 10.0), (5.1, 14.5), (5.35, 16.6),
                             (6.7, 17.95), (6.7, 18.6), (6.4, 18.9), (6.4, 19.3), (6.95, 19.85),
                             (6.95, 22.6), (4.7, 22.6), (4.7, 21.2), (0, 21.2)]
    P["bishop"] = base(8.5) + [(6.0, 5.35), (4.6, 6.3), (3.8, 8.0), (3.2, 11.0), (2.9, 14.5), (2.8, 16.8),
                               (4.8, 18.8), (4.8, 19.4), (3.0, 21.2), (3.0, 21.5), (4.5, 23.2),
                               (4.75, 24.2), (4.7, 25.2), (4.3, 26.6), (3.6, 28.0), (2.6, 29.3),
                               (1.6, 30.3), (1.15, 30.8)] + ball(1.15, 30.8, 1.6, 12)
    P["queen"] = base(9.25) + [(6.8, 5.3), (5.2, 6.4), (4.3, 8.2), (3.6, 12.0), (3.1, 17.0), (2.95, 21.5),
                               (5.35, 23.9), (5.35, 24.5), (3.5, 26.3), (3.3, 27.5), (3.6, 29.5),
                               (4.4, 31.8), (5.3, 33.4), (5.6, 34.0), (5.6, 34.4), (4.3, 34.4),
                               (3.5, 35.3), (2.6, 36.0), (1.3, 36.7)] + ball(1.3, 36.7, 1.75, 12)
    P["king"] = base(9.5) + [(7.0, 5.35), (5.4, 6.5), (4.5, 8.3), (3.8, 12.5), (3.25, 18.0), (3.1, 23.0),
                             (5.6, 25.5), (5.6, 26.1), (3.7, 28.0), (3.5, 29.2), (3.9, 31.0), (4.8, 33.2),
                             (5.5, 34.6), (5.5, 35.1), (4.6, 35.1), (3.4, 36.4), (2.0, 37.3), (1.3, 37.7),
                             (0, 37.9)]
    P["knight"] = base(8.5) + [(6.9, 4.6), (6.9, 7.0), (0, 7.0)]
    return P


def merlons(r_in, r_out, z0, z1, count=6, width_deg=34):
    out = []
    for i in range(count):
        c = i * 360 / count
        a = np.radians(np.linspace(c - width_deg / 2, c + width_deg / 2, 9))
        outer = np.c_[r_out * np.cos(a), r_out * np.sin(a)]
        inner = np.c_[r_in * np.cos(a[::-1]), r_in * np.sin(a[::-1])]
        out.append(extrude(np.vstack([outer, inner]), [], z0, z1))
    return out


def crown_points(r, z0, count, rad=0.8, h=1.7, n=24):        # 1.6 mm bases: crisp with a 0.4 nozzle
    out = []
    for i in range(count):
        a = 2 * np.pi * i / count + np.pi / count
        out.append(lathe([(0, 0), (rad, 0), (0, h)], n).translate(r * np.cos(a), r * np.sin(a), z0))
    return out


def cross(z0, zt, za, half_w=1.3, arm=3.6, t=2.3):
    p = [(-half_w, z0), (half_w, z0), (half_w, za - (arm - half_w)), (arm, za), (arm, za + t),
         (half_w, za + t), (half_w, zt), (-half_w, zt), (-half_w, za + t), (-arm, za + t),
         (-arm, za), (-half_w, za - (arm - half_w))]
    return loft_xz([p, p], [-half_w, half_w])


# ---- knight: layered sculpt (core head, thicker neck/cheeks, two ears, serrated mane, eyes)
CORE = [(-5.3, 0), (4.6, 0), (5.3, 1.8), (5.0, 3.6), (3.9, 5.6), (3.7, 6.6), (6.6, 9.5),
        (7.2, 10.1), (8.2, 11.1), (8.4, 12.3), (7.9, 13.2), (6.3, 14.4), (4.7, 15.9), (3.4, 17.4),
        (2.4, 18.9), (1.7, 20.1), (0.6, 20.7), (-0.6, 20.6), (-1.6, 20.0), (-2.8, 18.4), (-3.6, 16.6),
        (-4.3, 14.5), (-4.9, 12.0), (-5.4, 9.0), (-5.6, 6.0), (-5.6, 3.0)]
CHEEK = [(-5.0, 0), (4.4, 0), (5.0, 1.8), (4.7, 3.6), (3.6, 5.6), (3.4, 6.6), (5.7, 8.9), (4.2, 11.2),
         (1.5, 13.0), (-1.6, 14.2), (-4.0, 14.0), (-4.6, 12.0), (-5.1, 9.0), (-5.3, 6.0), (-5.3, 3.0)]
EAR = [(1.9, 18.6), (2.0, 19.4), (1.5, 21.0), (0.9, 23.3), (0.5, 23.7), (0.1, 23.2), (-0.5, 21.6), (-1.0, 20.0), (-0.8, 18.6)]
EYE = [(2.7, 15.5), (2.2, 15.9), (1.4, 15.9), (0.9, 15.4), (1.8, 14.5)]
MANE_BACK = [(-1.6, 20.0), (-2.8, 18.4), (-3.6, 16.6), (-4.3, 14.5), (-4.9, 12.0), (-5.4, 9.0), (-5.6, 6.0), (-5.6, 3.0), (-5.3, 0.0)]
HEAD = CORE  # kept for older scripts


def _bevel_loft(poly, ys, scales, pivot, z0):
    p = np.array(poly, float)
    pv = np.array(pivot, float)
    sl = [pv + (p - pv) * s + [0, z0] for s in scales]
    return loft_xz(sl, ys)


def _mane(z0):
    P = np.array(MANE_BACK, float)
    seg = np.diff(P, axis=0)
    L = np.r_[0, np.cumsum(np.hypot(seg[:, 0], seg[:, 1]))]
    s = np.arange(0, L[-1] + 1e-9, 0.2)
    x, z = np.interp(s, L, P[:, 0]), np.interp(s, L, P[:, 1])
    tx, tz = np.gradient(x), np.gradient(z)
    tn = np.hypot(tx, tz)
    nx, nz = tz / tn, -tx / tn          # outward (towards -x for a downward-running back line)
    if nx.mean() > 0:
        nx, nz = -nx, -nz
    period = 1.6
    tri = 1 - np.abs(((s / period) % 1) * 2 - 1)    # 0..1..0 triangle wave
    off = 0.35 + 0.6 * tri
    outer = np.c_[x + nx * off, z + nz * off]
    inner = np.c_[x - nx * 1.1, z - nz * 1.1][::-1]
    poly = np.vstack([outer, inner])
    if signed_area(poly) < 0:
        poly = poly[::-1]
    poly = poly + [0, z0]
    return loft_xz([poly, poly], [-0.9, 0.9])


def knight_parts(z0):
    parts = [_bevel_loft(CORE, [-2.8, -2.3, -1.6, 1.6, 2.3, 2.8], [0.86, 0.95, 1, 1, 0.95, 0.86], (0.8, 0), z0),
             _bevel_loft(CHEEK, [-3.8, -3.4, -2.9, 2.9, 3.4, 3.8], [0.84, 0.94, 1, 1, 0.94, 0.84], (-0.2, 0), z0),
             _mane(z0)]
    ear = np.array(EAR) + [0, z0]
    parts += [loft_xz([ear, ear], [0.4, 1.9]), loft_xz([ear, ear], [-1.9, -0.4])]
    eye = np.array(EYE) + [0, z0]
    parts += [loft_xz([eye, eye], [2.45, 3.2]), loft_xz([eye, eye], [-3.2, -2.45])]
    return parts


def knight_head(z0):
    return merge(knight_parts(z0))


WEIGHT_Z0, WEIGHT_Z1, WEIGHT_WALL = 1.2, 5.0, 1.4   # cavity floor / ceiling (pause) / wall


def weight_cavity_profile(P, z0=WEIGHT_Z0, z1=WEIGHT_Z1, wall=WEIGHT_WALL):
    """Largest axisymmetric cavity between z0..z1 keeping `wall` mm to the outer profile."""
    P = np.asarray(P, float)
    A, Bq = P[:-1], P[1:]
    side = ~((A[:, 1] < 0.01) & (Bq[:, 1] < 0.01))      # floor handled by z0
    A, Bq = A[side], Bq[side]
    def dist(r, z):
        q = np.array([r, z])
        d = Bq - A
        t = np.clip(((q - A) * d).sum(1) / np.maximum((d * d).sum(1), 1e-12), 0, 1)
        c = A + d * t[:, None]
        return np.hypot(*(c - q).T).min()
    pts = []
    for z in np.arange(z0, z1 + 1e-9, 0.1):
        r = 0.0
        while dist(r + 0.02, z) >= wall and r < 20:
            r += 0.02
        pts.append((round(r, 3), round(z, 3)))
    return [(0, z0)] + pts + [(0, z1)]


def build(kind, n=96, weights=True):
    P = profiles()[kind]
    shells = [lathe(P, n)]
    if weights:
        cav = lathe(weight_cavity_profile(P), n)
        shells.append(Mesh(cav.V, cav.F[:, ::-1]))
    if kind == "rook":
        shells += merlons(4.7, 6.95, 22.5, 25.6)
    if kind == "queen":
        shells += crown_points(4.95, 34.3, 9, n=max(12, n // 4))
    if kind == "king":
        shells.append(cross(37.6, 44.2, 40.6))
    if kind == "knight":
        shells += knight_parts(6.7)
    m = merge(shells)
    if K != 1.0:
        m = Mesh(m.V * K, m.F)
    return m, shells


BACK_RANK = ["rook", "knight", "bishop", "queen", "king", "bishop", "knight", "rook"]


def plate(n=96, pitch=26.0, cx=128.0, cy=128.0, weights=True):
    """32 pieces: rows (front->back) marble pawns, marble back rank, black back rank, black pawns."""
    marble, black = [], []
    for row, (kinds, dest, face) in enumerate([
            (["pawn"] * 8, marble, 90), (BACK_RANK, marble, 90),
            (BACK_RANK, black, -90), (["pawn"] * 8, black, -90)]):
        for col, kind in enumerate(kinds):
            m, _ = build(kind, n, weights=weights)
            m = m.rotate_z(face)
            x = cx + (col - 3.5) * pitch
            y = cy + (row - 1.5) * pitch
            dest.append(m.translate(x, y, 0))
    return merge(marble), merge(black)


if __name__ == "__main__":
    import sys
    from meshlib import check_closed, write_stl
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out = args[0] if args else "."
    weights = "--no-hardware" not in sys.argv
    for kind, prof in profiles().items():
        bad = check_overhang(prof, 50)
        m, shells = build(kind)
        ok = all(check_closed(s)[0] for s in shells)
        lo, hi = m.bounds()
        print(f"{kind:7s} H={hi[2]:5.1f}  base dia={2*hi[0]:5.1f}  closed={ok}  overhang>50: {bad}")
    mar, blk = plate(weights=weights)
    for name, m in [("marble", mar), ("black", blk)]:
        lo, hi = m.bounds()
        print(name, len(m.F), "tris  bounds", lo.round(1), hi.round(1))
        write_stl(f"{out}/pieces_{name}.stl", m, f"pieces_{name}")
