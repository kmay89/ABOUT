"""Closing simulation of the centre latch: lid tongue vs tray beams / end posts / slot, and tray beams vs lid pocket."""
import numpy as np
from scipy.interpolate import RegularGridInterpolator as RGI
from matplotlib.path import Path
import case
from case import *

nests, _, _ = layout()
L = latch()
xsA, ysA = grid([L["pocket"]]); hA = body_heights(0, True, xsA, ysA, nests, latch_geom=L, role="lid")
xsB, ysB = grid([L["slot"]]);   hB = body_heights(1, False, xsB, ysB, nests, latch_geom=L, role="tray")
iA, iB = RGI((ysA, xsA), hA), RGI((ysB, xsB), hB)
tongue = Path(L["tongue"])

beams, outer = [], []                 # inner beams + centre pads = the intended contact faces
u1 = BEAM_IN + BEAM_N * BEAM_T + (BEAM_N - 1) * BEAM_SEP
for s_ in (-1, 1):
    xa, xb = sorted((L["xc"] + s_ * BEAM_IN, L["xc"] + s_ * u1))
    beams.append((xa, xb, L["y0"] - 0.5, L["y1"] + 0.5, BEAM_BOT, BEAM_TOP))
posts = [(L["xc"] - L["sw"], L["xc"] + L["sw"], ya, yb, H - 0.05, BEAM_TOP)
         for ya, yb in ((L["y0"] - POST, L["y0"] + 0.3), (L["y1"] - 0.3, L["y1"] + POST))]
def in_boxes(P, boxes, tol=0.0):
    m = np.zeros(len(P), bool)
    for x0, x1, y0, y1, z0, z1 in boxes:
        m |= ((P[:, 0] > x0 + tol) & (P[:, 0] < x1 - tol) & (P[:, 1] > y0 + tol) & (P[:, 1] < y1 - tol)
              & (P[:, 2] > z0 + tol) & (P[:, 2] < z1 - tol))
    return m
def in_tray_body(P, tol=0.02):        # tray heightfield (B frame: A-like coords, y > 0)
    h = iB(np.c_[P[:, 1], P[:, 0]]); return (P[:, 2] > D) & (P[:, 2] < h - tol)
def in_lid_body(P, tol=0.02):
    h = iA(np.c_[P[:, 1], P[:, 0]]); return (P[:, 2] > D) & (P[:, 2] < h - tol)

# tongue sample points (lid frame), keep those above the pocket floor
g = np.mgrid[L["xc"] - 2.2:L["xc"] + 2.2:0.04, L["yc"] - TONGUE_LEN / 2:L["yc"] + TONGUE_LEN / 2:0.25, POCKET_FLOOR:L["tip"]:0.04].reshape(3, -1).T
g = g[tongue.contains_points(np.c_[g[:, 0], g[:, 2]])]
# tray latch sample points (B, A-like coords)
b = np.mgrid[L["xc"] - L["sw"]:L["xc"] + L["sw"]:0.05, L["y0"] - POST:L["y1"] + POST:0.25, BEAM_BOT:BEAM_TOP:0.05].reshape(3, -1).T
b = b[in_boxes(b, beams + posts)]
print(f"tongue pts {len(g)}, beam/post pts {len(b)}, tongue tip {L['tip'] - H:.2f} above lid rim, beams {BEAM_TOP - H:.2f} above tray rim, feet {R_K}")

def fold(P, deg):   # lid frame -> tray frame (A-like coords for both, mirrored fold about y = 0, z = H)
    t = np.radians(deg)
    y2 = P[:, 1] * np.cos(t) - (P[:, 2] - H) * np.sin(t)
    z2 = P[:, 1] * np.sin(t) + (P[:, 2] - H) * np.cos(t) + H
    return np.c_[P[:, 0], -y2, z2]          # mirror y back into the tray's A-like coords

for deg in [160, 170, 172, 174, 175, 176, 177, 178, 178.5, 179, 179.3, 179.6, 179.8, 180]:
    T = fold(g, deg)
    hit_beam = in_boxes(T, beams, 0.0)
    hit_post = in_boxes(T, posts, 0.02)
    hit_body = in_tray_body(T)
    pen = 0.0
    if hit_beam.any():
        dx = np.abs(T[hit_beam, 0] - L["xc"]) - BEAM_IN
        pen = dx.max()
    Bt = fold(b, -deg) if False else None
    # tray beams vs lid body: inverse fold of beam points into lid frame
    t = np.radians(deg)
    yb_, zb_ = -b[:, 1], b[:, 2]
    y1 = yb_ * np.cos(-t) - (zb_ - H) * np.sin(-t)
    z1 = yb_ * np.sin(-t) + (zb_ - H) * np.cos(-t) + H
    hit_lid = in_lid_body(np.c_[b[:, 0], y1, z1])
    print(f"{deg:6.1f} deg: tongue-in-beams {hit_beam.sum():5d} (max {pen:.2f} mm deep)  tongue-in-posts {hit_post.sum()}  "
          f"tongue-in-tray {hit_body.sum()}  beams-in-lid {hit_lid.sum()}")
