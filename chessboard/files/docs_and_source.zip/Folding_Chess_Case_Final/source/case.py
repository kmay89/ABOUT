"""Folding two-piece chess case.

Global "G" frame = the opened case lying TRAYS-UP (exactly how each half prints):
  face (playing surface) on the bed at z = 0, tray rims at z = H,
  hinge axis along X at (y = 0, z = H).  Half A (ranks 1-4) at y > 0, half B (ranks 5-8) at y < 0.
Closing = rotating A 180 deg about the hinge axis onto B. Each piece lies with its axis in the rim
plane, so half of every piece sits in A's nest and half in B's mirrored nest.
"""
import numpy as np
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
from matplotlib.path import Path
from meshlib import Mesh, box, extrude, lathe, merge, check_closed, write_stl

# ------------------------------------------------------------------ parameters
S, B_ = 25.0, 9.0                  # square, border (W = 218: fits 220 x 220 beds)
W = 8 * S + 2 * B_                 # 218 board width (x)
HD = 4 * S + B_                    # 109 half depth (y)
RC = 6.0                           # plan-view corner radius on the free-edge corners
H = 12.2                           # half thickness (face -> rim); closed case = 24.4 mm
D = 0.8                            # colour face depth
E = 0.01                           # anti-shared-edge inset for face tiles

R_K = 3.8                          # hinge knuckle radius (= protrusion = foot height)
R_BORE = 1.0                       # bore for 1.75 mm filament pin (teardrop, tip up)
C_K = 0.35                         # radial knuckle clearance
G_K = 0.25                         # axial gap each side of a knuckle
N_K = 10                           # knuckle segments (A owns even, B odd)
L_K = W / N_K

RIM_CH = 0.6                       # rim chamfer
FACE_CH = 0.6                      # playing-face edge chamfer (outer edges)
HINGE_CH = 0.4                     # face chamfer at the hinge seam (kills elephant's foot)
C_NEST = 0.35                      # nest clearance around the piece envelope
NEST_Y0 = 5.6                      # usable tray band starts here (hinge side)
NEST_Y1 = HD - 1.6                 # ... and ends here (free edge)
NEST_CH = 0.4                      # edge break on every nest rim
WALL = 1.6                         # wall between nests in a column
MARGIN_X = 3.6                     # outer wall beside the outermost nest columns
COL_GAP = 3.0                      # wall between nest columns; the leftover width becomes the centre strip


MAG_R, MAG_H = 3.15, 3.2           # 6 x 3 mm disc magnets (6.3 mm pocket: vertical holes print ~0.1-0.2 undersize)
BOSS_R, BOSS_H = 5.0, R_K          # boss height == knuckle protrusion -> flat feet when playing
SOCK_R, SOCK_D = 5.25, R_K + 0.2
BLK = 7.7                          # half-size of the corner boss/socket block
CORNER = [(BLK, HD - BLK), (W - BLK, HD - BLK)]

# heights that fall on 0.2 mm layer boundaries
SOCK_FLOOR = H - SOCK_D            # 8.2
SOCK_CAP0 = SOCK_FLOOR - 0.6       # 7.6   -> pause before the layer 7.6-7.8
SOCK_MAG0 = SOCK_CAP0 - MAG_H      # 4.4
BOSS_MAG0, BOSS_MAG1 = H, H + MAG_H        # 12.2 .. 15.4 -> pause before layer 15.4-15.6
BOSS_TOP = H + BOSS_H                      # 16.0

MAGNETS = True                     # False -> no magnet pockets anywhere (plain boss / socket)

# ---- centre latch (v9): lid tongue + draw-down barb between twin-beam in-plane springs in the tray -----
# Sized with snapfit_model.py: 2 x 0.8 mm beams per side, 44 mm span, 4.6 mm tall, 0.6 mm deflection.
# Working strain ~0.41 % (incl. stretching, Kt 1.25); hold ~640 g, close ~330 g; +/-0.1 mm print error -> +/-17 %.
LATCH_Y = 74.0                     # latch centre from the hinge (front half, next to the finger dish)
LATCH_L = 44.0                     # free span of the bridge beams
BEAM_T = 0.8                       # 2 extrusion lines, no gap fill
BEAM_N = 2                         # beams per side (parallel springs, joined by a centre pad)
BEAM_SEP = 0.8                     # gap between the beams of one side
BEAM_IN = 1.45                     # inner face of the inner beam, from the latch centre line
NECK = 1.2                         # tongue neck half-width (0.25 mm clearance to the beams)
LATCH_DELTA = 0.6                  # beam deflection to pass the barb
LATCH_PRE = 0.08                   # residual preload when closed: rattle-free draw-down, negligible creep
DEFL_GAP = LATCH_DELTA + 0.25 + 0.3   # room behind the outer beam (deflection + lid play + margin)
BEAM_BOT, BEAM_TOP = H - 1.2, H + 3.4 # layer-aligned (11.0 / 15.6); top stays below the 3.8 mm play feet
PAD_LEN = 3.0                      # centre pad that ties the beams of one side together
POST = 2.5                         # end posts above the rim
FILLET = 1.0                       # in-plane root fillets (gap between beams: 0.35)
ENTRY_DEG = 27.0                   # entry ramp from vertical: easy, smooth close
TONGUE_LEN = 5.0
POCKET_FLOOR = H - 3.9             # lid relief over the latch frame; the tongue rises from this floor

FONT = "/usr/share/fonts/truetype/google-fonts/ofl/archivoblack/ArchivoBlack-Regular.ttf"
GLYPH_H = 4.2
LINE_W, LINE_GAP = 0.8, 0.8        # black frame line around the playing field, 0.8 mm from the squares
R0, R1 = 1.1, 1.6                  # thin outer rule (0.5 mm = one first-layer line), 1.1 mm in from the edge
CSTAR = (2.2, 1.45, 0.8)            # corner star: long point, short point, inner radius
# interior maker's panels on the centre strip (A-like coords): recessed 0.6 mm, raised relief flush with the rim
PANEL_HW, PANEL_Y0, PANEL_Y1, PANEL_D = 4.5, 7.5, 47.0, 0.6
WORDMARK = "ERRERLabs"
WORD_FONT = "/usr/share/fonts/truetype/google-fonts/ofl/crimsontext/CrimsonText-Bold.ttf"
WORD_BOLD = 0.06                   # outline offset: hairlines ~0.5 mm, letters kept >= 0.45 mm apart
WORD_TRACK = 0.45                  # extra letter spacing (mm) so serifs never fuse

# ------------------------------------------------------------------ piece envelopes


def envelope(kind, c=C_NEST, step=0.05):
    """Radial envelope R(t) of a piece (any rotation about its axis), dilated by c."""
    from pieces import build
    m, _ = build(kind, 96)
    F = m.F
    e = np.unique(np.sort(np.vstack([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]), 1), axis=0)
    p, q = m.V[e[:, 0]], m.V[e[:, 1]]
    L = m.V[:, 2].max()
    s = np.arange(0, L + step, step)
    R = np.zeros_like(s)
    zlo, zhi = np.minimum(p[:, 2], q[:, 2]), np.maximum(p[:, 2], q[:, 2])
    for i, si in enumerate(s):
        k = (zlo <= si + 1e-9) & (zhi >= si - 1e-9)
        pp, qq = p[k], q[k]
        dz = qq[:, 2] - pp[:, 2]
        t = np.where(np.abs(dz) > 1e-12, (si - pp[:, 2]) / np.where(np.abs(dz) > 1e-12, dz, 1), 0.0)
        t = np.clip(t, 0, 1)
        pt = pp + (qq - pp) * t[:, None]
        r = np.hypot(pt[:, 0], pt[:, 1])
        if len(dz) and np.abs(dz).min() < 1e-12:   # horizontal edges at this height: both endpoints
            hz = np.abs(dz) < 1e-12
            r = np.concatenate([r, np.hypot(pp[hz, 0], pp[hz, 1]), np.hypot(qq[hz, 0], qq[hz, 1])])
        R[i] = r.max() if len(r) else 0
    # dilate along the axis by c (window max) then radially by c
    tt = np.arange(-c, L + c + step, step)
    Rd = np.zeros_like(tt)
    for i, ti in enumerate(tt):
        k = np.abs(s - ti) <= c + 1e-9
        Rd[i] = (R[k].max() + c) if k.any() else 0
    return tt, Rd, L


KINDS = ["pawn", "rook", "knight", "bishop", "queen", "king"]


def layout():
    """Columns of nests along Y. Marble set on the left, black set on the right (mirror order)."""
    env = {k: envelope(k) for k in KINDS}
    left = [["king", "queen"], ["pawn"] * 4, ["bishop", "bishop", "rook"],
            ["knight", "knight", "rook"], ["pawn"] * 4]
    cols = left + left[::-1]
    widths = [2 * max(env[k][1].max() for k in col) for col in cols]
    mid = len(cols) // 2
    centre = W - sum(widths) - 2 * MARGIN_X - COL_GAP * (len(cols) - 2)
    nests, x = [], MARGIN_X
    for ci, (col, w) in enumerate(zip(cols, widths)):
        xc = x + w / 2
        y = NEST_Y0
        for kind in col:
            tt, Rd, L = env[kind]
            length = tt[-1] - tt[0]
            nests.append(dict(kind=kind, xc=xc, y0=y - tt[0], t=tt, R=Rd, L=L,       # base end at hinge side
                              side=-1 if ci < len(cols) // 2 else 1))
            y += length + WALL
        assert y - WALL <= NEST_Y1 + 1e-6, (col, y)
        x += w + (centre if ci == mid - 1 else COL_GAP)
    return nests, centre, env


# ------------------------------------------------------------------ hinge geometry

def tear_lo(y, r):
    """Lower boundary z of a point-down teardrop (radius r, 45 deg flanks) around the hinge axis."""
    y = np.abs(y)
    a = H - r * np.sqrt(2) + y
    b = H - np.sqrt(np.clip(r * r - y * y, 0, None))
    return np.where(y <= r / np.sqrt(2), a, b)


def knuckle_poly(r=R_K, rb=R_BORE, n=48):
    a = np.radians(np.linspace(-45, 225, n))
    outer = [(r * np.cos(t), H + r * np.sin(t)) for t in a] + [(0.0, H - r * np.sqrt(2))]
    a = np.radians(np.linspace(135, 405, n // 2))
    hole = [(rb * np.cos(t), H + rb * np.sin(t)) for t in a][:-1] + [(0.0, H + rb * np.sqrt(2))]
    return np.array(outer[:-1] + [outer[-1]]), np.array(hole)


PERM = np.array([[0, 0, 1], [1, 0, 0], [0, 1, 0]], float)   # (u=y, v=z, w=x) -> (x, y, z)


def knuckle(xa, xb, blind_start=False):
    """Knuckle shells. blind_start adds a 1.2 mm solid cap at x = xa so the pin can only enter from the far end."""
    outer, hole = knuckle_poly()
    if blind_start:
        return [extrude(outer, [], xa, xa + 1.25).apply(PERM), extrude(outer, [hole], xa + 1.2, xb).apply(PERM)]
    return [extrude(outer, [hole], xa, xb).apply(PERM)]


def seg_range(k):
    xa, xb = k * L_K, (k + 1) * L_K
    return (xa if k == 0 else xa + G_K), (xb if k == N_K - 1 else xb - G_K)


# ------------------------------------------------------------------ helpers

M_XZY = np.array([[1, 0, 0], [0, 0, 1], [0, 1, 0]], float)   # (u=x, v=z, w=y) -> (x, y, z)


# ------------------------------------------------------------------ rounded corners

CORNER_CENTERS = [(RC, HD - RC), (W - RC, HD - RC)]


def warp(X, Y):
    """Map the square corner cells of the grid onto quarter discs (square->disc, no folding)."""
    X, Y = X.copy(), Y.copy()
    for cx, cy in CORNER_CENTERS:
        m = (np.abs(X - cx) <= RC + 1e-9) & (Y >= cy - 1e-9) & (((X - cx) * (cx - W / 2)) >= -1e-9)
        ux, uy = X[m] - cx, Y[m] - cy
        e = np.hypot(ux, uy)
        mx = np.maximum(np.abs(ux), np.abs(uy))
        f = np.where(e > 1e-9, mx / np.where(e > 1e-9, e, 1), 1)
        X[m], Y[m] = cx + ux * f, cy + uy * f
    return X, Y


def dist_outer(X, Y):
    """Distance to the three outer edges (rounded free-edge corners); the hinge edge is excluded."""
    d = np.minimum(np.minimum(X, W - X), HD - Y)
    for cx, cy in CORNER_CENTERS:
        m = (Y > cy) & (((X - cx) * (cx - W / 2)) > 0)
        d[m] = RC - np.hypot(X[m] - cx, Y[m] - cy)
    return d


def corner_block_poly(sx, sy, a=0.0, half=None):
    """Corner block square around (sx, sy) with its outer corner rounded (RC) and outer sides inset by a."""
    half = BLK if half is None else half
    left = sx < W / 2
    xo = 0.0 if left else W                       # outer x edge
    sgn = 1 if left else -1                       # direction from outer edge inward
    xi = sx + sgn * half                          # inner x edge
    yb = sy - half
    cx = xo + sgn * RC
    cy = HD - RC
    arc = [(cx - sgn * (RC - a) * np.cos(t), cy + (RC - a) * np.sin(t)) for t in np.radians(np.linspace(0, 90, 13))]
    pts = [(xo + sgn * a, yb), (xi, yb), (xi, HD - a), (cx, HD - a)] + arc[::-1][1:-1] + [(xo + sgn * a, cy)]
    return np.array(pts)


# ------------------------------------------------------------------ centre latch

def latch(xc=W / 2, yc=LATCH_Y):
    """Latch geometry around (xc, yc) in A-like coordinates. The tongue profile is designed in the closed tray
    frame (z_B) and mirrored into the lid frame (z_A = 2H - z_B)."""
    stack = BEAM_N * BEAM_T + (BEAM_N - 1) * BEAM_SEP
    sw = BEAM_IN + stack + DEFL_GAP                         # slot half-width
    y0, y1 = yc - LATCH_L / 2, yc + LATCH_L / 2
    a, n, d, p = BEAM_IN, NECK, LATCH_DELTA, LATCH_PRE
    zb = BEAM_BOT
    z_neck = zb + (a + p - n)                               # 45-degree shoulder meets the neck
    z_crest = zb - (d - p)                                  # shoulder passes the beam corner at (a + p, zb)
    z_flat = z_crest - 0.2
    lead = 0.2
    z_tip = z_flat - (d + lead) / np.tan(np.radians(ENTRY_DEG))
    prof_B = [(n, 2 * H - (POCKET_FLOOR - 0.05)), (n, z_neck), (a + d, z_crest), (a + d, z_flat), (a - lead, z_tip)]
    half = [(u, 2 * H - z) for u, z in prof_B]              # lid frame
    tongue = [(xc + u, z) for u, z in half] + [(xc - u, z) for u, z in half[::-1]]
    slot_floor = z_tip - 0.5
    return dict(xc=xc, yc=yc, sw=sw, y0=y0, y1=y1, tongue=np.array(tongue), tip_B=z_tip, tip=2 * H - z_tip,
                slot_floor=slot_floor, slot=(xc - sw, xc + sw, y0, y1),
                pocket=(xc - sw - 0.4, xc + sw + 0.4, y0 - POST - 0.4, y1 + POST + 0.4))


def filleted_bar(xlo, xhi, y0, y1, rlo, rhi, ext=0.5, nseg=8):
    """Plan outline of a bridge beam between anchors at y0 / y1, with concave root fillets on both faces."""
    def arc(cx, cy, r, a0, a1):
        return [(cx + r * np.cos(t), cy + r * np.sin(t)) for t in np.radians(np.linspace(a0, a1, nseg))]
    pts = [(xlo - rlo, y0 - ext), (xhi + rhi, y0 - ext), (xhi + rhi, y0)]
    pts += arc(xhi + rhi, y0 + rhi, rhi, 270, 180)[1:]
    pts += arc(xhi + rhi, y1 - rhi, rhi, 180, 90)
    pts += [(xhi + rhi, y1 + ext), (xlo - rlo, y1 + ext), (xlo - rlo, y1)]
    pts += arc(xlo - rlo, y1 - rlo, rlo, 90, 0)[1:]
    pts += arc(xlo - rlo, y0 + rlo, rlo, 0, -90)
    return np.array(pts[:-1])


def latch_tray_shells(L):
    out, xc = [], L["xc"]
    for s_ in (-1, 1):
        for j in range(BEAM_N):
            u0 = BEAM_IN + j * (BEAM_T + BEAM_SEP)
            r_in = FILLET if j == 0 else 0.35
            r_out = FILLET if j == BEAM_N - 1 else 0.35
            P = filleted_bar(u0, u0 + BEAM_T, L["y0"], L["y1"], r_in, r_out)
            P = np.c_[xc + s_ * P[:, 0], P[:, 1]]
            out.append(extrude(P, [], BEAM_BOT, BEAM_TOP))
        u1 = BEAM_IN + BEAM_N * BEAM_T + (BEAM_N - 1) * BEAM_SEP
        xa, xb = sorted((xc + s_ * BEAM_IN, xc + s_ * u1))
        out.append(box(xa, L["yc"] - PAD_LEN / 2, BEAM_BOT, xb, L["yc"] + PAD_LEN / 2, BEAM_TOP))   # centre pad
    for ya, yb in ((L["y0"] - POST, L["y0"] + 0.3), (L["y1"] - 0.3, L["y1"] + POST)):               # end posts
        for a_, z0_, z1_ in ((0.0, H - 0.05, BEAM_TOP - 0.4 + 0.01), (0.2, BEAM_TOP - 0.4, BEAM_TOP - 0.2 + 0.01),
                             (0.4, BEAM_TOP - 0.2, BEAM_TOP)):          # rounded plan, stepped 0.4 mm top chamfer
            out.append(extrude(rounded_rect(xc - L["sw"] + a_, xc + L["sw"] - a_, ya + a_, yb - a_, max(0.3, 1.2 - a_)), [], z0_, z1_))
    return out


def rounded_rect(x0, x1, y0, y1, r, n=6):
    pts = []
    for cx, cy, a0 in ((x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)):
        pts += [(cx + r * np.cos(t), cy + r * np.sin(t)) for t in np.radians(np.linspace(a0, a0 + 90, n))]
    return np.array(pts)


def latch_lid_shells(L):
    return [extrude(L["tongue"], [], L["yc"] - TONGUE_LEN / 2, L["yc"] + TONGUE_LEN / 2).apply(M_XZY)]


# ------------------------------------------------------------------ maker's panels (raised relief)

def star_poly(cx, cy, r_long, r_short, r_in, rot=0.0):
    pts = []
    for k in range(8):
        a = np.radians(rot + 45 * k)
        r = r_long if k % 2 == 0 else r_short
        pts.append((cx + r * np.cos(a), cy + r * np.sin(a)))
        b = a + np.radians(22.5)
        pts.append((cx + r_in * np.cos(b), cy + r_in * np.sin(b)))
    return np.array(pts)


def _rdp(P, tol):
    if len(P) < 3:
        return P
    a, b = P[0], P[-1]
    ab = b - a
    n = np.hypot(*ab)
    q = P - a
    d = np.abs(ab[0] * q[:, 1] - ab[1] * q[:, 0]) / n if n > 1e-12 else np.hypot(q[:, 0], q[:, 1])
    i = int(np.argmax(d))
    if d[i] > tol:
        return np.vstack([_rdp(P[:i + 1], tol)[:-1], _rdp(P[i:], tol)])
    return np.array([a, b])


def bold_text(txt, font, height, length, bold, track=0.0, res=0.02):
    """Outline of `txt` scaled to fit height x length (centred at 0), grown by `bold` mm via a distance field.
    Returns [(outer, [holes])]."""
    from scipy import ndimage
    import contourpy
    prop = FontProperties(fname=font)
    def layout_(tr):
        from matplotlib.textpath import TextToPath
        t2p, polys = TextToPath(), []
        for i, ch in enumerate(txt):
            x = (t2p.get_text_width_height_descent(txt[:i], prop, ismath=False)[0] if i else 0.0) * 10 / prop.get_size_in_points()
            tp = TextPath((x + i * tr, 0), ch, size=10, prop=prop)
            polys += [np.asarray(p, float) for p in tp.to_polygons(closed_only=True) if len(p) >= 4]
        return polys
    polys = layout_(0.0)
    allv = np.vstack(polys)
    s0 = min(height / np.ptp(allv[:, 1]), length / np.ptp(allv[:, 0]))
    polys = layout_(track / s0)
    allv = np.vstack(polys)
    lo, hi = allv.min(0), allv.max(0)
    s = min(height / (hi - lo)[1], length / (hi - lo)[0])
    polys = [(p - (lo + hi) / 2) * s for p in polys]
    ext = (hi - lo) * s / 2 + 0.4
    gx = np.arange(-ext[0], ext[0], res); gy = np.arange(-ext[1], ext[1], res)
    GX, GY = np.meshgrid(gx, gy)
    pts = np.c_[GX.ravel(), GY.ravel()]
    ins = np.zeros(len(pts), bool)
    for p in polys:
        ins ^= Path(p).contains_points(pts)
    ins = ins.reshape(GX.shape)
    sdf = (ndimage.distance_transform_edt(~ins) - ndimage.distance_transform_edt(ins)) * res
    lines = contourpy.contour_generator(gx, gy, sdf).lines(bold)
    rings = []
    for L_ in lines:
        L_ = np.asarray(L_)
        if np.hypot(*(L_[0] - L_[-1])) < 1e-6:
            L_ = L_[:-1]
        L_ = _rdp(np.vstack([L_, L_[:1]]), 0.006)[:-1]
        if len(L_) >= 3:
            rings.append(L_)
    P = [Path(r) for r in rings]
    depth = [sum(P[j].contains_point(r[0]) for j in range(len(rings)) if j != i) for i, r in enumerate(rings)]
    out = []
    for i, r in enumerate(rings):
        if depth[i] % 2 == 0:
            holes = [rings[j] for j in range(len(rings)) if depth[j] == depth[i] + 1 and P[i].contains_point(rings[j][0])]
            out.append((r, holes))
    return out


def _relief(shapes):
    z0 = H - PANEL_D - 0.05
    return [extrude(o, h, z0, H) for o, h in shapes]


def wordmark_shells():
    """ERRERLabs in raised serif relief, reading from the hinge outward (bottom-to-top seen from the front)."""
    x0, x1, y0, y1 = panel_rect()
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    shapes = bold_text(WORDMARK, WORD_FONT, height=2 * PANEL_HW - 4.0, length=(y1 - y0) - 4.5, bold=WORD_BOLD, track=WORD_TRACK)
    rot = lambda P: np.c_[cx - P[:, 1], cy + P[:, 0]]           # +90 deg: text baseline runs along +y
    return _relief([(rot(o), [rot(h) for h in hs]) for o, hs in shapes])


def ornament_shells():
    """Tray panel: compass star on a rule, diamond finials (same star language as the board corners)."""
    x0, x1, y0, y1 = panel_rect()
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    half = (y1 - y0) / 2
    shapes = [(star_poly(cx, cy, 3.4, 2.3, 1.35), [])]      # point bases >= 1 mm: prints as solid relief
    for s_ in (-1, 1):
        a, b = cy + s_ * 4.0, cy + s_ * (half - 4.4)
        ya, yb = sorted((a, b))
        shapes.append((np.array([[cx - 0.4, ya], [cx + 0.4, ya], [cx + 0.4, yb], [cx - 0.4, yb]]), []))
        tip = cy + s_ * (half - 2.0)
        shapes.append((np.array([[cx, b - s_ * 0.6], [cx + 1.0, (b + tip) / 2], [cx, tip], [cx - 1.0, (b + tip) / 2]]), []))
    return _relief(shapes)


# ------------------------------------------------------------------ heightfield body

def grid(cuts=(), x_span=(0, W), y_span=(0, HD)):
    xs = np.arange(x_span[0], x_span[1] + 1e-9, 0.5)
    ys = np.concatenate([np.arange(y_span[0], 8.0, 0.2), np.arange(8.0, y_span[1] + 1e-9, 0.5)])
    ex, ey = [], []
    for x0, x1, y0, y1 in cuts:                  # near-vertical cut walls (node pairs 0.02 apart) + edge-break nodes
        ex += [x0 - 0.4, x0 - 0.02, x0, x1, x1 + 0.02, x1 + 0.4]
        ey += [y0 - 0.4, y0 - 0.02, y0, y1, y1 + 0.02, y1 + 0.4]
    xs = np.unique(np.round(np.clip(np.concatenate([xs, ex]), *x_span), 4))
    ys = np.unique(np.round(np.clip(np.concatenate([ys, ey]), *y_span), 4))
    return xs, ys


def panel_rect():
    return (W / 2 - PANEL_HW, W / 2 + PANEL_HW, PANEL_Y0, PANEL_Y1)


def body_heights(parity, boss_left, xs, ys, nests, socket_xy=None, rim_chamfer=True, latch_geom=None, role=None, XY=None,
                 panel=False):
    X, Y = np.meshgrid(xs, ys) if XY is None else XY
    h = np.full(X.shape, H)
    if panel:
        x0, x1, y0, y1 = panel_rect()
        dd = np.hypot(np.maximum(np.maximum(x0 - X, X - x1), 0), np.maximum(np.maximum(y0 - Y, Y - y1), 0))
        inside = (X >= x0 - 1e-6) & (X <= x1 + 1e-6) & (Y >= y0 - 1e-6) & (Y <= y1 + 1e-6)
        h = np.where(inside, H - PANEL_D, np.where(dd < NEST_CH, H - (NEST_CH - dd), H))
    # nests
    for n in nests:
        Rm = n["R"].max()
        sel = (np.abs(X - n["xc"]) < Rm + NEST_CH) & (Y >= n["y0"] + n["t"][0] - 0.01) & (Y <= n["y0"] + n["t"][-1] + 0.01)
        t = Y[sel] - n["y0"]
        R = np.interp(t, n["t"], n["R"], left=0, right=0)
        d = np.abs(X[sel] - n["xc"])
        dep = np.sqrt(np.clip(R * R - d * d, 0, None))
        brk = np.where(R > 0.5, np.clip(R + NEST_CH - d, 0, None), 0)     # 45 deg edge break on the rim
        h[sel] = np.minimum(h[sel], H - np.maximum(dep, np.minimum(brk, NEST_CH)))
    # 0.6 mm chamfer on the rim's three outer edges -> crisp V-groove at the parting line when closed
    if rim_chamfer:
        h = np.minimum(h, H - RIM_CH + dist_outer(X, Y))
    # thumb dish at the middle of the free edge
    q = ((X - W / 2) / 13.0) ** 2 + ((Y - HD) / 8.0) ** 2
    h = np.minimum(h, np.where(q < 1, H - 3.0 * (1 - q), H))
    # hinge zone
    for k in range(N_K):
        xa, xb = k * L_K, (k + 1) * L_K
        if k % 2 == parity:     # own knuckle: body rises to meet the knuckle's lower flank
            sel = (X >= xa) & (X <= xb) & (Y <= R_K)
            h[sel] = np.minimum(h[sel], tear_lo(Y[sel], R_K) + 0.05)
        else:                   # partner's knuckle: clearance notch (+ one grid cell of ramp margin)
            sel = (X >= xa - G_K - 0.5) & (X <= xb + G_K + 0.5) & (Y <= R_K + C_K)
            h[sel] = np.minimum(h[sel], tear_lo(Y[sel], R_K + C_K))
    # own-knuckle columns must still give way to the partner's notch ramps -> re-apply notches
    for k in range(N_K):
        if k % 2 != parity:
            xa, xb = k * L_K, (k + 1) * L_K
            sel = (X >= xa - G_K) & (X <= xb + G_K) & (Y <= R_K + C_K)
            h[sel] = np.minimum(h[sel], tear_lo(Y[sel], R_K + C_K))
    # centre latch: beam slot in the tray, relief pocket in the lid
    if latch_geom is not None:
        x0, x1, y0, y1 = latch_geom["slot"] if role == "tray" else latch_geom["pocket"]
        sel = (X >= x0 - 1e-6) & (X <= x1 + 1e-6) & (Y >= y0 - 1e-6) & (Y <= y1 + 1e-6)
        h[sel] = np.minimum(h[sel], latch_geom["slot_floor"] if role == "tray" else POCKET_FLOOR)
        dx = np.maximum(np.maximum(x0 - X, X - x1), 0); dy = np.maximum(np.maximum(y0 - Y, Y - y1), 0)
        dd = np.hypot(dx, dy)
        h = np.minimum(h, np.where(dd < NEST_CH, H - (NEST_CH - dd), H))          # 0.4 mm edge break
    # socket corner: heightfield drops to the magnet-well floor; blocks build the rest
    sx, sy = socket_xy if socket_xy else (CORNER[1] if boss_left else CORNER[0])
    sel = ((X >= sx - BLK + 0.5 - 1e-9) & (X <= sx + BLK - 0.5 + 1e-9) & (Y >= sy - BLK + 0.5 - 1e-9) & (Y <= sy + BLK - 0.5 + 1e-9))
    h[sel] = SOCK_MAG0
    assert h.min() > D + 1.3, h.min()
    return h


def heightfield_solid(xs, ys, h, zb, XY=None):
    nx, ny = len(xs), len(ys)
    X, Y = np.meshgrid(xs, ys) if XY is None else XY
    V = np.c_[X.ravel(), Y.ravel(), h.ravel()]
    idx = np.arange(nx * ny).reshape(ny, nx)
    a, b, c, d = idx[:-1, :-1].ravel(), idx[:-1, 1:].ravel(), idx[1:, 1:].ravel(), idx[1:, :-1].ravel()
    F = [np.c_[a, b, c], np.c_[a, c, d]]
    ring = np.concatenate([idx[0, :], idx[1:, -1], idx[-1, -2::-1], idx[-2:0:-1, 0]])
    nb = len(V)
    Vb = np.c_[V[ring, 0], V[ring, 1], np.full(len(ring), zb)]
    cen = nb + len(ring)
    V = np.vstack([V, Vb, [[xs.mean(), ys.mean(), zb]]])
    rb = nb + np.arange(len(ring))
    an, bn = ring, np.roll(ring, -1)
    ab, bb = rb, np.roll(rb, -1)
    F += [np.c_[bn, an, ab], np.c_[bn, ab, bb], np.c_[np.full(len(ring), cen), bb, ab]]
    return Mesh(V, np.vstack(F)).oriented()


def corner_parts(boss_left, boss_xy=None, sock_xy=None, chamfer=True):
    bx, by = boss_xy if boss_xy else (CORNER[0] if boss_left else CORNER[1])
    sx, sy = sock_xy if sock_xy else (CORNER[1] if boss_left else CORNER[0])
    parts = []
    # boss (sealed magnet cavity at its tip when MAGNETS)
    prof = [(0, H - 0.05), (BOSS_R, H - 0.05), (BOSS_R, BOSS_TOP - 0.6), (BOSS_R - 0.6, BOSS_TOP), (0, BOSS_TOP)]
    parts.append(lathe(prof, 96).translate(bx, by, 0))
    if MAGNETS:
        cav = lathe([(0, BOSS_MAG0), (MAG_R, BOSS_MAG0), (MAG_R, BOSS_MAG1), (0, BOSS_MAG1)], 96)
        parts.append(Mesh(cav.V, cav.F[:, ::-1]).translate(bx, by, 0))       # inward normals = void
    # socket block: magnet well -> cap -> socket
    rect = (corner_block_poly(sx, sy) if chamfer else
            np.array([[sx - BLK, sy - BLK], [sx + BLK, sy - BLK], [sx + BLK, sy + BLK], [sx - BLK, sy + BLK]]))
    circ = lambda r: np.c_[sx + r * np.cos(np.linspace(0, 2 * np.pi, 96, endpoint=False)),
                           sy + r * np.sin(np.linspace(0, 2 * np.pi, 96, endpoint=False))]
    if MAGNETS:
        parts.append(extrude(rect, [circ(MAG_R)], SOCK_MAG0 - 0.05, SOCK_CAP0 + 0.05))
        parts.append(extrude(rect, [], SOCK_CAP0, SOCK_FLOOR + 0.05))
    else:
        parts.append(extrude(rect, [], SOCK_MAG0 - 0.05, SOCK_FLOOR + 0.05))
    parts.append(extrude(rect, [circ(SOCK_R)], SOCK_FLOOR, H - 0.6 + 0.01))
    left_side = sx < W / 2
    if not chamfer:
        parts.append(extrude(rect, [circ(SOCK_R + 0.15)], H - 0.6, H - 0.3 + 0.01))
        parts.append(extrude(rect, [circ(SOCK_R + 0.45)], H - 0.3, H))
        return parts
    def rect_in(a):   # inset only the outer sides (x edge, rounded corner, free edge)
        return corner_block_poly(sx, sy, a)
    parts.append(extrude(rect_in(0.15), [circ(SOCK_R + 0.15)], H - 0.6, H - 0.3 + 0.01))
    parts.append(extrude(rect_in(0.45), [circ(SOCK_R + 0.45)], H - 0.3, H))
    return parts


def body(parity, boss_left, nests):
    L = latch()
    role = "lid" if parity == 0 else "tray"
    xs, ys = grid([L["slot"] if role == "tray" else L["pocket"], panel_rect()])
    XY = warp(*np.meshgrid(xs, ys))
    h = body_heights(parity, boss_left, xs, ys, nests, latch_geom=L, role=role, XY=XY, panel=True)
    shells = [heightfield_solid(xs, ys, h, D, XY=XY)]
    shells += latch_tray_shells(L) if role == "tray" else latch_lid_shells(L)
    shells += wordmark_shells() if role == "lid" else ornament_shells()
    for k in range(N_K):
        if k % 2 == parity:
            shells += knuckle(*seg_range(k), blind_start=(k == 0))
    shells += corner_parts(boss_left)
    return shells, h


# ------------------------------------------------------------------ face (play frame -> G)

def glyph_polys(ch):
    tp = TextPath((0, 0), ch, size=10, prop=FontProperties(fname=FONT))
    return [np.asarray(p, float) for p in tp.to_polygons(closed_only=True) if len(p) >= 4]


GSCALE = GLYPH_H / max(np.ptp(np.vstack(glyph_polys(c))[:, 1]) for c in "abcdefgh12345678")


def placed_glyph(ch, cx, cy, rot180):
    polys = glyph_polys(ch)
    allp = np.vstack(polys)
    c0 = (allp.min(0) + allp.max(0)) / 2
    out = [((p - c0) * GSCALE * (-1 if rot180 else 1)) + [cx, cy] for p in polys]
    paths = [Path(p) for p in out]
    depth = [sum(paths[j].contains_point(p[0]) for j in range(len(out)) if j != i) for i, p in enumerate(out)]
    return out, depth


def face(half):
    """Colour face of one half, modelled in the play frame (A = ranks 1-4 at play y 0..HD, B = ranks 5-8 at
    play y HD..W) and returned in the G frame. Keys: white, black, marble (+ black_squares for the mono kit)."""
    wh, bl, mb, sq = [], [], [], []
    z0, z1 = H - D, H
    y_out = 0.0 if half == "A" else W
    y_hinge = HD
    zs = [0.0, 0.2, 0.4, 0.6, D]

    def layered(poly_fn, chamfer):
        """Stack of extrusions from the bed: sublayer k uses poly_fn(inset_k)."""
        out, k = [], 0
        while k < 4:
            a = max(0.0, chamfer - 0.2 * k)
            last = a == 0 or k == 3
            g0, g1 = zs[k], (D if last else zs[k + 1] + 0.01)
            outer, holes = poly_fn(a)
            out.append(extrude(outer, holes, H - g1, H - g0))
            if last:
                break
            k += 1
        return out

    def tile(x0, y0, x1, y1, holes=()):
        """Rect tile with stepped chamfers on the edges that lie on the half's boundary."""
        ch = {"l": FACE_CH if abs(x0) < 1e-6 else 0, "r": FACE_CH if abs(x1 - W) < 1e-6 else 0}
        for side, yy in (("b", y0), ("t", y1)):
            ch[side] = FACE_CH if abs(yy - y_out) < 1e-6 else (HINGE_CH if abs(yy - y_hinge) < 1e-6 else 0)
        cmax = max(ch.values())
        def poly(a):
            ins = {k_: max(0.0, c - (cmax - a)) for k_, c in ch.items()}
            return (np.array([[x0 + E + ins["l"], y0 + E + ins["b"]], [x1 - E - ins["r"], y0 + E + ins["b"]],
                              [x1 - E - ins["r"], y1 - E - ins["t"]], [x0 + E + ins["l"], y1 - E - ins["t"]]]), list(holes))
        return layered(poly, cmax)

    # playing squares (a1 dark)
    ranks = range(0, 4) if half == "A" else range(4, 8)
    for f in range(8):
        for r in ranks:
            x, y = B_ + f * S, B_ + r * S
            t = tile(x, y, x + S, y + S)
            if (f + r) % 2 == 0:
                bl.extend(t); sq.extend(t)
            else:
                wh.extend(t)

    def glyph(ch_, cx, cy, rot):
        polys, depth = placed_glyph(ch_, cx, cy, rot)
        P = [Path(p) for p in polys]
        for i, (p, d) in enumerate(zip(polys, depth)):
            holes = [polys[j] for j in range(len(polys)) if depth[j] == d + 1 and P[i].contains_point(polys[j][0])]
            (bl if d % 2 == 0 else mb).append(extrude(p, holes, z0, z1))
        return [p for p, d in zip(polys, depth) if d == 0]

    LO = B_ - LINE_W - LINE_GAP            # width of the outer (lettered) band
    def band(x0, y0, x1, y1, inward, ch_, rot):
        """Border cell split into: lettered band | black line | marble gap, ordered along `inward`."""
        if inward in ("+x", "-x"):
            sgn = 1 if inward == "+x" else -1
            xo = x0 if sgn > 0 else x1
            cuts = [xo + sgn * c for c in (0, R0, R1, LO, LO + LINE_W, B_)]
            rects = [tuple(sorted(cuts[k:k + 2])) for k in range(5)]
            boxes = [(a, y0, b, y1) for a, b in rects]
            gc = ((boxes[2][0] + boxes[2][2]) / 2, (y0 + y1) / 2)
        else:
            sgn = 1 if inward == "+y" else -1
            yo = y0 if sgn > 0 else y1
            cuts = [yo + sgn * c for c in (0, R0, R1, LO, LO + LINE_W, B_)]
            rects = [tuple(sorted(cuts[k:k + 2])) for k in range(5)]
            boxes = [(x0, a, x1, b) for a, b in rects]
            gc = ((x0 + x1) / 2, (boxes[2][1] + boxes[2][3]) / 2)
        holes = glyph(ch_, gc[0], gc[1], rot)
        mb.extend(tile(*boxes[0]))
        bl.extend(tile(*boxes[1]))
        mb.extend(tile(*boxes[2], holes))
        bl.extend(tile(*boxes[3]))
        mb.extend(tile(*boxes[4]))

    if half == "A":
        for i in range(8):
            band(B_ + i * S, 0, B_ + (i + 1) * S, B_, "+y", "abcdefgh"[i], False)
    else:
        for i in range(8):
            band(B_ + i * S, W - B_, B_ + (i + 1) * S, W, "-y", "abcdefgh"[i], True)
    for r in ranks:
        a = B_ + r * S
        band(0, a, B_, a + S, "+x", "12345678"[r], False)
        band(W - B_, a, W, a + S, "-x", "12345678"[r], True)

    # corners: rounded outer corner (RC), L-shaped frame line, chamfered outer edges
    def corner(sx, sy):        # sx, sy = +1/-1: direction from the outer corner into the board
        ox, oy = (0.0 if sx > 0 else W), (0.0 if sy > 0 else W)
        T_ = lambda pts: np.array([(ox + sx * u, oy + sy * v) for u, v in pts])
        arc = lambda r, a0, a1: [(RC + r * np.cos(t), RC + r * np.sin(t)) for t in np.radians(np.linspace(a0, a1, 13))][1:-1]
        def outer(a):
            pts = [(RC, a), (B_, a), (B_, R0), (RC, R0)] + arc(RC - R0, 270, 180) + [(R0, RC), (R0, B_), (a, B_), (a, RC)] \
                + arc(RC - a, 180, 270)
            return T_(pts), []
        mb.extend(layered(outer, FACE_CH))
        ring = [(RC, R0), (B_, R0), (B_, R1), (RC, R1)] + arc(RC - R1, 270, 180) + [(R1, RC), (R1, B_), (R0, B_), (R0, RC)] \
            + arc(RC - R0, 180, 270)
        bl.append(extrude(T_(ring), [], z0, z1))
        c = (R1 + LO) / 2
        st = T_(star_poly(c, c, *CSTAR))
        inner = [(RC, R1), (B_, R1), (B_, LO), (LO, LO), (LO, B_), (R1, B_), (R1, RC)] + arc(RC - R1, 180, 270)
        mb.append(extrude(T_(inner), [st], z0, z1))
        bl.append(extrude(st, [], z0, z1))
        Lp = [(LO, LO), (B_, LO), (B_, LO + LINE_W), (LO + LINE_W, LO + LINE_W), (LO + LINE_W, B_), (LO, B_)]
        bl.append(extrude(T_(Lp), [], z0, z1))
        g = LO + LINE_W
        mb.append(extrude(T_([(g, g), (B_, g), (B_, B_), (g, B_)]), [], z0, z1))

    if half == "A":
        corner(1, 1); corner(-1, 1)
    else:
        corner(1, -1); corner(-1, -1)

    # play frame -> G frame: (x, y, z) -> (x, HD - y, H - z)
    T = np.diag([1.0, -1.0, -1.0])
    conv = lambda L: [m.apply(T).translate(0, HD, H) for m in L]
    return {"white": conv(wh), "black": conv(bl), "marble": conv(mb), "black_squares": conv(sq)}


MIRROR_Y = np.diag([1.0, -1.0, 1.0])


def build_half(half, nests):
    if half == "A":
        shells, h = body(parity=0, boss_left=True, nests=nests)
    else:  # B is the fold-mirror of an A-like half that owns the odd knuckles and has the boss on the right
        shells, h = body(parity=1, boss_left=False, nests=nests)
        shells = [s.apply(MIRROR_Y) for s in shells]
    parts = {"body": shells}
    fc = face(half)
    sq = fc.pop("black_squares")
    parts.update(fc)
    return parts, h, sq


def two_colour(parts):
    """Light = case body + light squares + border; dark = dark squares, lettering, rules and stars."""
    return {"light": parts["body"] + parts["white"] + parts["marble"], "dark": parts["black"]}


def inlay_tiles(n=32, clearance=0.1):
    """Dark squares for the single-colour kit: printed face-down, 0.2 mm edge break on the visible face."""
    a = S - 2 * clearance
    out = []
    for i in range(n):
        x, y = (i % 8) * (a + 2), (i // 8) * (a + 2)
        out.append(extrude(np.array([[x + 0.2, y + 0.2], [x + a - 0.2, y + 0.2], [x + a - 0.2, y + a - 0.2], [x + 0.2, y + a - 0.2]]), [], 0, 0.21))
        out.append(extrude(np.array([[x, y], [x + a, y], [x + a, y + a], [x, y + a]]), [], 0.2, D))
    return merge(out)


def coupon(which):
    """Fit test (white only): 2 hinge knuckles, boss/socket (magnet pauses if MAGNETS) and the full centre latch."""
    YMAX = 58.0
    L = latch(xc=12.0, yc=30.0)
    parity = 0 if which == "A" else 1
    role = "lid" if which == "A" else "tray"
    xs, ys = grid([L["slot"] if role == "tray" else L["pocket"]], x_span=(0, 2 * L_K), y_span=(0, YMAX))
    xs[-1] = 2 * L_K
    pos = (34.0, 44.0)
    h = body_heights(parity, True, xs, ys, [], socket_xy=pos if which == "B" else (-99, -99),
                     rim_chamfer=False, latch_geom=L, role=role)
    shells = [heightfield_solid(xs, ys, h, 0.0)]
    k = parity
    a, b = k * L_K + (0 if k == 0 else G_K), (k + 1) * L_K - G_K
    shells += knuckle(a, b, blind_start=(k == 0))
    nb = 2 if MAGNETS else 1                         # boss shells come first
    if which == "A":
        shells += corner_parts(True, boss_xy=pos, sock_xy=(-50, -50), chamfer=False)[:nb]
        shells += latch_lid_shells(L)
    else:
        shells += corner_parts(True, boss_xy=(-50, -50), sock_xy=pos, chamfer=False)[nb:]
        shells += latch_tray_shells(L)
        shells = [s_.apply(MIRROR_Y) for s_ in shells]
    return shells


if __name__ == "__main__":
    import sys, time
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out = args[0] if args else "."
    if "--no-hardware" in sys.argv:
        MAGNETS = False
    t0 = time.time()
    nests, gap, env = layout()
    tiles_all = []
    print(f"layout: {len(nests)} nests, centre strip {gap:.2f} mm, max nest R {max(n['R'].max() for n in nests):.2f}")
    for half in "AB":
        parts, h, sq = build_half(half, nests)
        # single-colour kit: everything but the dark squares, glyphs and frame line in one STL
        mono = merge(parts["body"] + parts["white"] + parts["marble"])
        write_stl(f"{out}/mono_half_{half}.stl", mono, f"mono_half_{half}")
        tiles_all.append(sq)
        for name, shells in two_colour(parts).items():
            bad = [check_closed(s)[1] for s in shells if not check_closed(s)[0]]
            m = merge(shells)
            lo, hi = m.bounds()
            print(f"half {half} {name:6s} {len(shells):3d} shells {len(m.F):7d} tris bad={bad[:2]} "
                  f"bounds {lo.round(2)} {hi.round(2)}")
            write_stl(f"{out}/half_{half}_{name}.stl", m, f"half_{half}_{name}")
        print(" min floor", round(h.min(), 2))
    write_stl(f"{out}/mono_inlay_tiles.stl", inlay_tiles(), "mono_inlay_tiles")
    for w in "AB":
        sh = coupon(w)
        print("coupon", w, [check_closed(x)[0] for x in sh])
        write_stl(f"{out}/fit_test_{w}.stl", merge(sh), f"fit_test_{w}")
    print(f"{time.time()-t0:.1f}s")
