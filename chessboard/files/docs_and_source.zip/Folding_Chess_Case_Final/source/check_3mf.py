"""Structural validation of the generated Bambu project 3MF."""
import zipfile, json, sys, re
import numpy as np
import xml.etree.ElementTree as ET
from meshlib import Mesh, check_closed

path = sys.argv[1]
z = zipfile.ZipFile(path)
names = set(z.namelist())
NS3 = "{http://schemas.microsoft.com/3dmanufacturing/core/2015/02}"
NSP = "{http://schemas.microsoft.com/3dmanufacturing/production/2015/06}"
errs = []
def err(m): errs.append(m); print("ERROR", m)

# 1. well-formed XML
for n in names:
    if n.endswith((".model", ".rels", ".config", ".xml")) and n != "Metadata/project_settings.config":
        try: ET.fromstring(z.read(n))
        except ET.ParseError as e: err(f"{n}: {e}")
ps = json.loads(z.read("Metadata/project_settings.config"))

# 2. root model
root = ET.fromstring(z.read("3D/3dmodel.model"))
meta = {m.get("name"): m.text for m in root.iter(NS3 + "metadata")}
assert meta["Application"].startswith("BambuStudio-"), "Application"
comps, items = {}, {}
for o in root.find(NS3 + "resources"):
    comps[o.get("id")] = [(c.get(NSP + "path"), c.get("objectid")) for c in o.iter(NS3 + "component")]
for it in root.find(NS3 + "build"):
    t = list(map(float, it.get("transform").split()))
    items[it.get("objectid")] = np.array(t[9:12])
# rels
rels = ET.fromstring(z.read("3D/_rels/3dmodel.model.rels"))
targets = {r.get("Target").lstrip("/") for r in rels}
# 3. sub models + meshes
sub = {}
for path_ in {p for v in comps.values() for p, _ in v}:
    fn = path_.lstrip("/")
    if fn not in names: err(f"missing {fn}")
    if fn not in targets: err(f"{fn} not in rels")
    m = ET.fromstring(z.read(fn))
    for o in m.find(NS3 + "resources"):
        V = np.array([[float(v.get(a)) for a in "xyz"] for v in o.iter(NS3 + "vertex")])
        F = np.array([[int(t.get(a)) for a in ("v1", "v2", "v3")] for t in o.iter(NS3 + "triangle")])
        sub[(path_, o.get("id"))] = Mesh(V, F)
# 4. model_settings
ms = ET.fromstring(z.read("Metadata/model_settings.config"))
ext_used = {}
for o in ms.findall("object"):
    oid = o.get("id")
    if oid not in comps: err(f"settings object {oid} not in model")
    cids = {c for _, c in comps[oid]}
    for p in o.findall("part"):
        if p.get("id") not in cids: err(f"part {p.get('id')} not a component of {oid}")
        ext = {m.get("key"): m.get("value") for m in p.findall("metadata")}["extruder"]
        ext_used.setdefault(oid, set()).add(int(ext))
plates = {}
for pl in ms.findall("plate"):
    pm = {m.get("key"): m.get("value") for m in pl.findall("metadata")}
    ids = [ {m.get("key"): m.get("value") for m in mi.findall("metadata")}["object_id"] for mi in pl.findall("model_instance")]
    plates[int(pm["plater_id"])] = (pm["plater_name"], ids)
allp = [i for _, ids in plates.values() for i in ids]
if sorted(allp) != sorted(comps): err("object/plate membership mismatch")
# 5. geometry: closed parts, inside plate, clear of prime tower
COLS, BED, GAP = 3, 256.0, 0.2
origin = lambda i: np.array([(i % COLS) * BED * (1 + GAP), -(i // COLS) * BED * (1 + GAP)])
wtx, wty = float(ps["wipe_tower_x"][0]), float(ps["wipe_tower_y"][0])
for pidx, (pname, ids) in sorted(plates.items()):
    o0 = origin(pidx - 1)
    lo_all, hi_all, tris, exts = np.full(3, 1e9), np.full(3, -1e9), 0, set()
    for oid in ids:
        for path_, cid in comps[oid]:
            m = sub[(path_, cid)]
            ok, msg = check_closed(m)
            if not ok: err(f"{pname} {oid}/{cid}: {msg}")
            v = m.V + items[oid]
            lo_all, hi_all = np.minimum(lo_all, v.min(0)), np.maximum(hi_all, v.max(0))
            tris += len(m.F)
        exts |= ext_used[oid]
    lo_l, hi_l = lo_all[:2] - o0, hi_all[:2] - o0
    inside = (lo_l >= 0).all() and (hi_l <= BED).all()
    tower_clear = hi_l[0] < wtx or hi_l[1] < wty
    print(f"plate {pidx} {pname:24s} objs={len(ids):2d} tris={tris:7d} filaments={sorted(exts)} "
          f"x[{lo_l[0]:.1f},{hi_l[0]:.1f}] y[{lo_l[1]:.1f},{hi_l[1]:.1f}] z<={hi_all[2]:.1f} "
          f"inside={inside} tower_clear={tower_clear if len(exts) > 1 else 'n/a'}")
    if not inside: err(f"plate {pidx} outside bed")
    if len(exts) > 1 and not tower_clear: err(f"plate {pidx} overlaps prime tower")
# 6. project settings consistency
n = len(ps["filament_colour"])
for k in ["filament_settings_id", "filament_type", "filament_self_index", "filament_extruder_variant", "filament_map"]:
    if len(ps[k]) != n: err(f"{k} size {len(ps[k])} != {n}")
if len(ps["flush_volumes_matrix"]) != n * n: err("flush matrix")
if len(ps["wipe_tower_x"]) != len(plates) or len(ps["wipe_tower_y"]) != len(plates): err("wipe tower arrays")
if len(ps["different_settings_to_system"]) != n + 2: err("different_settings_to_system size")
for key in ps["different_settings_to_system"][0].split(";"):
    if key not in ps: err(f"listed change {key} missing")
# 7. pauses on layer boundaries
cg = ET.fromstring(z.read("Metadata/custom_gcode_per_layer.xml")) if "Metadata/custom_gcode_per_layer.xml" in names else None
print("pauses:", "none" if cg is None else "")
for pl in ([] if cg is None else cg.findall("plate")):
    pid = int(pl.find("plate_info").get("id"))
    lh = 0.16 if pid in (4, 5) else 0.2
    for L in pl.findall("layer"):
        zt = float(L.get("top_z"))
        k = (zt - 0.2) / lh
        ok = abs(k - round(k)) < 1e-6 and L.get("type") == "1"
        print(f"  pause plate {pid} z={zt:<5} layer#{round(k) + 1:<3} {'ok' if ok else 'NOT ON A LAYER'}  {L.get('extra')}")
        if not ok: err(f"pause {pid} {zt}")
sets = {}
for o in ms.findall("object"):
    md = {m.get("key"): m.get("value") for m in o.findall("metadata")}
    k = tuple((a, b) for a, b in md.items() if a not in ("name", "extruder"))
    sets[k] = sets.get(k, 0) + 1
print("per-object settings:", sets)
print("thumbnails:", sorted(n for n in names if n.endswith(".png")))
print("RESULT:", "PASS" if not errs else f"{len(errs)} errors")
