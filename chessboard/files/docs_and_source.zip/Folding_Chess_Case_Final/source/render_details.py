"""Close-ups of the final details: lid maker's panel, tray ornament, board corner."""
import numpy as np, sys, time
from render import render
from case import *
from meshlib import merge

LIGHT = "white" if "--light-white" in sys.argv else "marble"
mats = {"body": LIGHT, "white": LIGHT, "black": "black", "marble": LIGHT}
nests, _, _ = layout()
t0 = time.time()
halves = {h: build_half(h, nests)[0] for h in "AB"}
items = lambda h: [(merge(s), mats[n]) for n, s in halves[h].items()]
cx, cy = W / 2, (PANEL_Y0 + PANEL_Y1) / 2
# 1. lid panel (G frame, trays up), seen from the front of the open case, low raking light angle
img = render(items("A"), eye=(cx - 38, cy - 70, H + 62), target=(cx, cy, H - 1), size=(1400, 900), fov=30)
img.save("v10_out/detail_wordmark.png"); print("wordmark", time.time() - t0)
# 2. tray ornament (tray B is mirrored: panel at negative y)
img = render(items("B"), eye=(cx + 40, -cy - 62, H + 66), target=(cx, -cy, H - 1), size=(1400, 900), fov=30)
img.save("v10_out/detail_tray_star.png"); print("tray", time.time() - t0)
# 3. board corner in play position (face up): flip A about x, look at the a1 corner
P2G = np.diag([1.0, -1.0, -1.0])
face_items = [(m.apply(P2G).translate(0, HD, H), mat) for m, mat in items("A")]
img = render(face_items, eye=(-25, -40, 70), target=(14, 14, 0), size=(1400, 900), fov=30)
img.save("v10_out/detail_corner.png"); print("corner", time.time() - t0)
