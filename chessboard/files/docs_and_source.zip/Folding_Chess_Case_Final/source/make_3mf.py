"""Write a Bambu Studio project (.3mf) for the AMS version of the folding chess case (Bambu Lab P2S).

Plates
  1  Fit test        fit_test_A + fit_test_B (hinge, latch, boss/socket)   white   pauses 7.8, 15.6
  2  Lid (half A)    light (body + light squares + border) -> 1, dark -> 2   pauses 7.8, 15.6
  3  Tray (half B)   same                                                    pauses 7.8, 15.6
  4  Light pieces    16 objects -> 1, 0.16 mm layers                         pause 5.16
  5  Black pieces    16 objects -> 2, 0.16 mm layers                         pause 5.16

Format notes (Bambu Studio bbs_3mf.cpp):
  * project config is only read when the root model's Application metadata starts with "BambuStudio-"
  * project_settings.config is merged over FullPrintConfig defaults, then each preset is matched to the
    named system preset; keys not listed in different_settings_to_system come from the system preset
  * filament_self_index / filament_extruder_variant must have one entry per filament
  * per-part filament = <metadata key="extruder"> on the <part> in model_settings.config
  * pauses live in Metadata/custom_gcode_per_layer.xml (type 1 = PausePrint)
"""
import io, json, math, uuid, zipfile, sys
import numpy as np
from PIL import Image

import case
from case import layout, build_half, coupon, envelope, two_colour, NEST_Y0, H, W, HD
HARDWARE = True        # False: snap-latch closure, solid pieces, no pauses
from pieces import build as build_piece, BACK_RANK
from meshlib import merge, Mesh

APP = "BambuStudio-02.07.00.00"
BED = 256.0
GAP = 0.2                      # LOGICAL_PART_PLATE_GAP
N_PLATES = 5
COLS = math.ceil(math.sqrt(N_PLATES))   # compute_colum_count: 5 plates -> 3 columns

PRINTER = "Bambu Lab P2S 0.4 nozzle"
PROCESS = "0.20mm Standard @BBL P2S"
FILAMENT = "Bambu PLA Basic @BBL P2S"
LIGHT = "white" if "--light-white" in sys.argv else "marble"     # two filaments: 1 light, 2 dark
FIL_COLOURS = ["#FFFFFF" if LIGHT == "white" else "#CFCAC2", "#161616"]
FIL_NAMES = [f"{LIGHT.capitalize()} PLA", "Black PLA"]


def plate_origin(i):            # i = 0-based plate index
    col, row = i % COLS, i // COLS
    return col * BED * (1 + GAP), -row * BED * (1 + GAP)


# --------------------------------------------------------------------------- scene
class Obj:
    def __init__(self, name, parts, plate, xy, settings=None, extruder=1):
        self.name, self.parts, self.plate, self.xy = name, parts, plate, xy
        self.settings = settings or {}
        self.extruder = extruder


def centred(meshes):
    """Translate a group of meshes so the group's XY bbox centre is at 0 and min z = 0."""
    allv = np.vstack([m.V for m in meshes])
    lo, hi = allv.min(0), allv.max(0)
    d = np.array([-(lo[0] + hi[0]) / 2, -(lo[1] + hi[1]) / 2, -lo[2]])
    return [Mesh(m.V + d, m.F) for m in meshes], hi - lo


def build_scene():
    nests, _, _ = layout()
    objs = []
    # plate 1: fit test (white)
    fa, sa = centred([merge(coupon("A"))])
    fb, sb = centred([merge(coupon("B"))])
    solid = {} if HARDWARE else {"sparse_infill_density": "100%"}
    objs += [Obj("Fit test - lid (tongue, boss)", [("fit_test_A", fa[0], 1)], 0, (90, 128)),
             Obj("Fit test - tray (latch beams, socket)", [("fit_test_B", fb[0], 1)], 0, (166, 128))]
    # plates 2-3: halves
    for k, half, label in [(1, "A", "Lid (ranks 1-4)"), (2, "B", "Tray (ranks 5-8)")]:
        parts, _, _ = build_half(half, nests)
        parts = two_colour(parts)
        names = ["light", "dark"]
        ext = {"light": 1, "dark": 2}
        meshes, size = centred([merge(parts[n]) for n in names])
        objs.append(Obj(f"Board half {half} - {label}",
                        [(f"{half} {n}", m, ext[n]) for n, m in zip(names, meshes)], k,
                        (128, 20 + size[1] / 2)))
    # plates 4-5: pieces, 2 rows of 8, 0.16 mm layers
    for k, colour, ext in [(3, LIGHT, 1), (4, "black", 2)]:
        kinds = BACK_RANK + ["pawn"] * 8
        for i, kind in enumerate(kinds):
            m, _ = build_piece(kind, 96, weights=HARDWARE)
            (m,), _ = centred([m])
            row, col = divmod(i, 8)
            objs.append(Obj(f"{colour.capitalize()} {kind} {i + 1}", [(kind, m, ext)], k,
                            (128 + (col - 3.5) * 27, 128 + (0.5 - row) * 30), {"layer_height": "0.16", **solid}, ext))
    return objs


# --------------------------------------------------------------------------- xml helpers
NS = ('xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" '
      'xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" '
      'xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06" requiredextensions="p"')


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


def mesh_xml(oid, m):
    V = np.round(m.V, 5)
    out = [f' <object id="{oid}" p:UUID="{uuid.uuid4()}" type="model">\n  <mesh>\n   <vertices>\n']
    out.append("".join(f'    <vertex x="{x:g}" y="{y:g}" z="{z:g}"/>\n' for x, y, z in V))
    out.append("   </vertices>\n   <triangles>\n")
    out.append("".join(f'    <triangle v1="{a}" v2="{b}" v3="{c}"/>\n' for a, b, c in m.F))
    out.append("   </triangles>\n  </mesh>\n </object>\n")
    return "".join(out)


def write_project(objs, path, thumbs):
    files = {}
    pid = 1
    part_ids = []                      # per object: list of mesh ids
    for k, o in enumerate(objs):
        ids = []
        body = [f'<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" {NS}>\n',
                ' <metadata name="BambuStudio:3mfVersion">1</metadata>\n <resources>\n']
        for _, m, _ in o.parts:
            body.append(mesh_xml(pid, m))
            ids.append(pid)
            pid += 1
        body.append(" </resources>\n <build/>\n</model>\n")
        files[f"3D/Objects/object_{k + 1}.model"] = "".join(body)
        part_ids.append(ids)
    comp_ids = [pid + k for k in range(len(objs))]

    # root model
    r = [f'<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" {NS}>\n',
         f' <metadata name="Application">{APP}</metadata>\n',
         ' <metadata name="BambuStudio:3mfVersion">1</metadata>\n',
         f' <metadata name="Title">Folding Chess Case - {"Magnets + Weights" if HARDWARE else "Standard"}</metadata>\n',
         ' <metadata name="Designer">ERRERLabs</metadata>\n',
         ' <metadata name="Description">Folding travel chess case: board halves fold into a 24 mm case holding all 32 '
         'pieces; printed filament-pin hinge; engineered twin-spring snap latch; ERRERLabs maker panel. Two filaments. Plates: fit test, lid, tray, '
         'light pieces, black pieces.</metadata>\n',
         ' <metadata name="License">All rights reserved</metadata>\n',
         ' <resources>\n']
    for k, o in enumerate(objs):
        r.append(f'  <object id="{comp_ids[k]}" p:UUID="{uuid.uuid4()}" type="model">\n   <components>\n')
        for mid in part_ids[k]:
            r.append(f'    <component p:path="/3D/Objects/object_{k + 1}.model" objectid="{mid}" '
                     f'p:UUID="{uuid.uuid4()}" transform="1 0 0 0 1 0 0 0 1 0 0 0"/>\n')
        r.append("   </components>\n  </object>\n")
    r.append(f' </resources>\n <build p:UUID="{uuid.uuid4()}">\n')
    for k, o in enumerate(objs):
        ox, oy = plate_origin(o.plate)
        r.append(f'  <item objectid="{comp_ids[k]}" p:UUID="{uuid.uuid4()}" '
                 f'transform="1 0 0 0 1 0 0 0 1 {ox + o.xy[0]:.4f} {oy + o.xy[1]:.4f} 0" printable="1"/>\n')
    r.append(" </build>\n</model>\n")
    files["3D/3dmodel.model"] = "".join(r)

    rels = ['<?xml version="1.0" encoding="UTF-8"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n']
    for k in range(len(objs)):
        rels.append(f' <Relationship Target="/3D/Objects/object_{k + 1}.model" Id="rel-{k + 1}" '
                    'Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n')
    rels.append("</Relationships>\n")
    files["3D/_rels/3dmodel.model.rels"] = "".join(rels)

    files["_rels/.rels"] = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
        ' <Relationship Target="/3D/3dmodel.model" Id="rel-1" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n'
        ' <Relationship Target="/Metadata/plate_1.png" Id="rel-2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/thumbnail"/>\n'
        '</Relationships>\n')
    files["[Content_Types].xml"] = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\n'
        ' <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>\n'
        ' <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>\n'
        ' <Default Extension="png" ContentType="image/png"/>\n'
        ' <Default Extension="gcode" ContentType="text/x.gcode"/>\n'
        '</Types>\n')

    # model_settings.config
    plate_names = ["Fit test: hinge + latch", "Lid - half A", "Tray - half B", f"{LIGHT.capitalize()} pieces", "Black pieces"]
    ms = ['<?xml version="1.0" encoding="UTF-8"?>\n<config>\n']
    for k, o in enumerate(objs):
        ms.append(f'  <object id="{comp_ids[k]}">\n')
        ms.append(f'    <metadata key="name" value="{esc(o.name)}"/>\n')
        ms.append(f'    <metadata key="extruder" value="{o.extruder}"/>\n')
        for key, val in o.settings.items():
            ms.append(f'    <metadata key="{key}" value="{esc(val)}"/>\n')
        for (pname, m, ext), mid in zip(o.parts, part_ids[k]):
            ms.append(f'    <part id="{mid}" subtype="normal_part">\n')
            ms.append(f'      <metadata key="name" value="{esc(pname)}"/>\n')
            ms.append('      <metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>\n')
            ms.append(f'      <metadata key="extruder" value="{ext}"/>\n')
            ms.append(f'      <mesh_stat face_count="{len(m.F)}" edges_fixed="0" degenerate_facets="0" '
                      'facets_removed="0" facets_reversed="0" backwards_edges="0"/>\n')
            ms.append('    </part>\n')
        ms.append('  </object>\n')
    ident = 100
    for p in range(N_PLATES):
        ms.append('  <plate>\n')
        ms.append(f'    <metadata key="plater_id" value="{p + 1}"/>\n')
        ms.append(f'    <metadata key="plater_name" value="{esc(plate_names[p])}"/>\n')
        ms.append('    <metadata key="locked" value="false"/>\n')
        ms.append(f'    <metadata key="thumbnail_file" value="Metadata/plate_{p + 1}.png"/>\n')
        for k, o in enumerate(objs):
            if o.plate == p:
                ident += 1
                ms.append('    <model_instance>\n')
                ms.append(f'      <metadata key="object_id" value="{comp_ids[k]}"/>\n')
                ms.append('      <metadata key="instance_id" value="0"/>\n')
                ms.append(f'      <metadata key="identify_id" value="{ident}"/>\n')
                ms.append('    </model_instance>\n')
        ms.append('  </plate>\n')
    ms.append('</config>\n')
    files["Metadata/model_settings.config"] = "".join(ms)

    # pauses
    pauses = {0: [(7.8, "Socket: insert 6x3 magnet, dot DOWN"), (15.6, "Boss: insert 6x3 magnet, dot UP")],
              1: [(7.8, "Socket: insert 6x3 magnet, dot DOWN"), (15.6, "Boss: insert 6x3 magnet, dot UP")],
              2: [(7.8, "Socket: insert 6x3 magnet, dot DOWN"), (15.6, "Boss: insert 6x3 magnet, dot UP")],
              3: [(5.16, "Fill weight cavities flush")],
              4: [(5.16, "Fill weight cavities flush")]}
    modes = {0: "MultiAsSingle", 1: "MultiExtruder", 2: "MultiExtruder", 3: "MultiAsSingle", 4: "MultiAsSingle"}
    cg = ['<?xml version="1.0" encoding="utf-8"?>\n<custom_gcodes_per_layer>\n']
    for p, items in pauses.items():
        cg.append(f'<plate>\n<plate_info id="{p + 1}"/>\n')
        for z, msg in items:
            cg.append(f'<layer top_z="{z}" type="1" extruder="1" color="" extra="{esc(msg)}" gcode="M400 U1"/>\n')
        cg.append(f'<mode value="{modes[p]}"/>\n</plate>\n')
    cg.append('</custom_gcodes_per_layer>\n')
    if HARDWARE:
        files["Metadata/custom_gcode_per_layer.xml"] = "".join(cg)

    # project settings: system presets + the handful of deliberate changes
    changed = {
        "wall_loops": "3",
        "bottom_shell_layers": "5",
        "bottom_surface_pattern": "monotonicline",
        "sparse_infill_pattern": "gyroid",
        "sparse_infill_density": "15%",
        "enable_prime_tower": "1",
        "wipe_tower_x": ["165"] * N_PLATES,
        "wipe_tower_y": ["175"] * N_PLATES,
    }
    n = len(FIL_COLOURS)
    flush = ["0", "160",
             "560", "0"]
    ps = {
        "name": "project_settings",
        "from": "project",
        "printer_settings_id": PRINTER,
        "printer_model": "Bambu Lab P2S",
        "printer_variant": "0.4",
        "nozzle_diameter": ["0.4"],
        "printable_height": "256",
        "printable_area": ["0x0", "256x0", "256x256", "0x256"],
        "print_settings_id": PROCESS,
        "filament_settings_id": [FILAMENT] * n,
        "filament_colour": FIL_COLOURS,
        "filament_type": ["PLA"] * n,
        "filament_self_index": [str(i + 1) for i in range(n)],
        "filament_extruder_variant": ["Direct Drive Standard"] * n,
        "filament_map": ["1"] * n,
        "flush_volumes_matrix": flush,
        "flush_volumes_vector": ["140"] * (2 * n),
        "flush_multiplier": ["1"],
        "curr_bed_type": "Textured PEI Plate",
        "layer_height": "0.2",
        "initial_layer_print_height": "0.2",
        "different_settings_to_system": [";".join(sorted(changed))] + [""] * n + [""],
        "inherits_group": [""] * (n + 2),
    }
    ps.update(changed)
    files["Metadata/project_settings.config"] = json.dumps(ps, indent=4)

    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name in ["[Content_Types].xml", "_rels/.rels", "3D/3dmodel.model", "3D/_rels/3dmodel.model.rels"]:
            z.writestr(name, files.pop(name))
        for name in sorted(files):
            z.writestr(name, files[name])
        for name, png in thumbs.items():
            z.writestr(name, png)
    return files


def plate_thumbs(objs):
    from render import render
    thumbs = {}
    for p in range(N_PLATES):
        items = []
        for o in objs:
            if o.plate != p:
                continue
            for _, m, ext in o.parts:
                mat = {1: LIGHT, 2: "black"}[ext]
                items.append((m.translate(o.xy[0], o.xy[1], 0), mat))
        img = render(items, eye=(128, -60, 260), target=(128, 120, 0), size=(512, 512), fov=40,
                     bg=(0.93, 0.93, 0.93), ssaa=1)
        buf = io.BytesIO(); img.save(buf, "PNG")
        thumbs[f"Metadata/plate_{p + 1}.png"] = buf.getvalue()
        sm = io.BytesIO(); img.resize((128, 128)).save(sm, "PNG")
        thumbs[f"Metadata/plate_{p + 1}_small.png"] = sm.getvalue()
    return thumbs


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if "--no-hardware" in sys.argv:
        HARDWARE = False
        case.MAGNETS = False
    out = args[0] if args else ("Folding_Chess_Case_Magnets_Weights.3mf" if HARDWARE else "Folding_Chess_Case_Standard.3mf")
    objs = build_scene()
    thumbs = plate_thumbs(objs)
    try:
        cover = Image.open("case_out/render_board.png").convert("RGB")
        w, h = cover.size; s = min(w, h)
        cover = cover.crop(((w - s) // 2, (h - s) // 2, (w + s) // 2, (h + s) // 2)).resize((512, 512))
        buf = io.BytesIO(); cover.save(buf, "PNG")
        thumbs["Auxiliaries/.thumbnails/thumbnail_3mf.png"] = buf.getvalue()
    except FileNotFoundError:
        pass
    write_project(objs, out, thumbs)
    print("wrote", out, len(objs), "objects")
