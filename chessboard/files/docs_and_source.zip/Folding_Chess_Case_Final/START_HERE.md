# Folding Chess Case: final version

A travel chess set that folds into a **218 × 109 × 24 mm** case holding all 32 pieces.
- **Two filaments for everything:** Light (marble by default) and Black.
- **Board:** 25 mm squares, printed face-down for a glass-smooth surface. Thick-and-thin double rule,
  compass-star corners.
- **Maker's mark:** **ERRERLabs** in raised serif lettering, set in a recessed panel inside the lid.
  The tray has a matching star panel.
- **Hinge:** a printed hinge with a filament pin.
- **Latch:** an engineered twin-spring snap.
- **Printing:** no supports anywhere. Fits any 220 × 220 mm bed.

## Pick your edition

| | **Standard** (recommended) | **Magnets + Weights** |
|---|---|---|
| Project | `Bambu_Studio/Folding_Chess_Case_Standard.3mf` | `Bambu_Studio/Folding_Chess_Case_Magnets_Weights.3mf` |
| Buy | nothing | 4 × 6×3 mm magnets, ~110 g tungsten putty (or fine shot) |
| Pauses | none | 2 per board half, 1 per piece plate (already set up) |
| Pieces | solid, 100 % infill | hollow core with ballast |
| Closure | twin-spring snap latch | same latch, plus magnets at the corners |

Both editions use the same latch, hinge and nests. You only need about 22 cm of 1.75 mm filament for the hinge pin.

## Bambu Studio + AMS (P2S, or any Bambu with an AMS)
1. Open the `.3mf` with File → Open Project. Two filaments: **1 Light (Marble PLA) · 2 Black PLA**.
   Prefer white? Map slot 1 to White PLA in the print dialog; nothing else changes.
2. **Plate 1 – fit test.** Pin the two pieces with a short filament pin and close them. You should
   feel a firm push, a click, and then the pieces pull themselves shut.
3. **Plates 2–3 – lid and tray.** Don't rotate them: the plate forms the playing surface.
4. **Plates 4–5 – pieces.** Marble and black, at 0.16 mm layers.

If Bambu Studio says "load geometry only", click OK. Then:
1. Select **P2S 0.4 · 0.20mm Standard**.
2. Add 2 PLA filaments.
3. For Magnets + Weights only, re-add the pauses from `docs/PRINT_GUIDE.md`.

## Other printers and slicers
Use the `STL/` folder. Each edition has four numbered sub-folders, in print order.
- **Two-colour board:** for each half, load `half_X_light` + `half_X_dark` as one multi-part object.
- **Single-colour board:** the board has 0.8 mm pockets, plus 32 inlay tiles to print in a dark colour. `docs/PRINT_GUIDE.md` has every setting.

## Assembly (2 minutes)
1. Lay both halves tray-side up so the knuckles interleave.
2. Push the 1.75 mm filament pin in from the **h-file end** until it stops. Cut it flush and add a drop of thin CA.
3. Lay the pieces in their nests: marble on the left, black on the right, bases toward the hinge.
4. Close the lid until the latch clicks. To open, pull up at the finger notch.

## Folder map
- **Bambu_Studio/**: the two ready-to-print projects.
- **STL/Standard, STL/Magnets_Weights/**: 1 fit test, 2 two-colour board, 3 single-colour board, 4 pieces.
- **docs/**: PRINT_GUIDE (settings, pauses, troubleshooting), DESIGN_NOTES (what the fit tests taught),
  LATCH_DESIGN (snap engineering), LISTING (text for Printables/MakerWorld).
- **renders/**: cover images.
- **source/**: the parametric Python generator. `python3 make_3mf.py [--no-hardware]` rebuilds everything.
